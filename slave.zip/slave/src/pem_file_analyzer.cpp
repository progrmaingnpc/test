#include "include/pem_file_analyzer.h"

void PemHandler::open_essential_tools()
{
    if(open_certificate_pem("certs/icmp_certificate.pem") == -1) {
        exit(EXIT_FAILURE);
    }
    cout << "[Certificate was succesfully opened]" << endl;

    if(open_openssl_buffers() == -1) {
        exit(EXIT_FAILURE);
    }
    cout << "[Successfully created openssl buffers]" << endl;

    if(extract_certificate_from_file() == -1) {
        exit(EXIT_FAILURE);
    }
    cout << "[Successfully extracted certificate data from file]" << endl;
}

int PemHandler::open_certificate_pem(string file_name)
{
    this->fp1 = fopen(file_name.c_str(), "rb");

    if (!this->fp1)
    {
        printf("Failed to open file: %s\n", strerror(errno));
        return -1;
    }

    return 0;
}

int PemHandler::open_openssl_buffers()
{
    this->pub_bio = BIO_new(BIO_s_mem());

    if (this->pub_bio == nullptr) {
        cerr << "Error creating BIO" << endl;
        return -1;
    }

    return 0;
}

int PemHandler::extract_certificate_from_file()
{
    string yo =
    "-----BEGIN CERTIFICATE-----\n"
    "MIIDbjCCAlagAwIBAgIUE9rzTFVZZwzBG9FHRSxJHTXJLJkwDQYJKoZIhvcNAQEL\n"
    "BQAwOzELMAkGA1UEBhMCVVMxHjAcBgNVBAoMFUdvb2dsZSBUcnVzdCBTZXJ2aWNl\n"
    "czEMMAoGA1UEAwwDV1IyMB4XDTI1MDQxMDE4MDUxMFoXDTI2MDQxMDE4MDUxMFow\n"
    "FzEVMBMGA1UEAwwMKi5nb29nbGUuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A\n"
    "MIIBCgKCAQEA574zTg/rX048SNiBYTMQHSM1iQKMAr3MCZfokyzrddVmvpcLHHkJ\n"
    "kLbuiq4VIGVQQ13KPTfBGeBIq45LWyKK8kaQSbQlhhuGf9ykIm5yf0Mb17V64oHj\n"
    "KOOIA1iAxCzSGVQfy/Q9717O4D5biZ059WwuxvI7OHrnihuG/LIX5ZEpwus5pWFm\n"
    "zY1Q/muEhLFcp9kg+voxFAEo/HcS+07h+UZCEupJvKinuA36It12gvxPzg7yrzHb\n"
    "pc7OLeig5a1k9V0uXIrfthPKjMTEDZ2kkpDI3MAQ+LlZKhrYe4odM8n10dTnyJ05\n"
    "33Ic9ExUwqZGSNtsGJQfuuBefLt2ivM5JQIDAQABo4GNMIGKMA4GA1UdDwEB/wQE\n"
    "AwIHgDATBgNVHSUEDDAKBggrBgEFBQcDATAMBgNVHRMBAf8EAjAAMB0GA1UdDgQW\n"
    "BBSRMqs+lZ66CBWlthuV40siyZL7tjAfBgNVHSMEGDAWgBSRMqs+lZ66CBWlthuV\n"
    "40siyZL7tjAVBgNVHREEDjAMggRlZWVlggRlZWVlMA0GCSqGSIb3DQEBCwUAA4IB\n"
    "AQCEBVc3LmZhqBu7HHyEhM1Zs4OHw8mw1Uh62yJOJ7ufZybxZqmyf+qI+YCBP0sX\n"
    "M89PVtTF48KTvlhc+7+nFeP83HpqjKhZSSGaTAajXe8snWBlnqrK7QSQ8CQxjGDF\n"
    "H5htl731QVxvVsuX+1auLdVC+5mfVuQe7rcJ+VwLEVJEPGPgX85HYyUCjdR4GQz4\n"
    "AY/xoX+WjFDeM2Qap2VSTUIKYdG1AZ5f3E826BF4BAP0QY6D9+a7YVwWyGt87Zaq\n"
    "bbIBuZ54cx/Pvsfdr+a/IDDNQmYnvXh8C/ZA1GHCETumbVu54gQ/ktg99JUlvRLb\n"
    "OIhQsPp6FWvlFjiVA7GzVSuM\n"
    "-----END CERTIFICATE-----";
    BIO_write(this->pub_bio, yo.c_str(), yo.length());

    this->cert = PEM_read_bio_X509(this->pub_bio, NULL, NULL, NULL);
    if (!this->cert) {
        cout << "ERRRORRR" << endl;
        return -1;
    }

    return 0;
}

string PemHandler::remove_unnecessary_details(string pem_buffer)
{
    string clean_buffer = pem_buffer;
    clean_buffer.erase(remove(
        clean_buffer.begin(),
        clean_buffer.end(), ':'), clean_buffer.end());

    clean_buffer.erase(remove(
        clean_buffer.begin(),
        clean_buffer.end(), ' '), clean_buffer.end());

    return clean_buffer;
}

string PemHandler::extract_public_tools()
{
    string public_key_buffer;
    char public_buffer[2048];

    if(EVP_PKEY_print_public(this->pub_bio, this->public_key, 0, NULL)) {

        BIO_read(this->pub_bio, public_buffer, 2048);
        string temp_public_buffer  = public_buffer;
        cout << "from file " << temp_public_buffer << endl;
        temp_public_buffer = remove_unnecessary_details(temp_public_buffer);
        public_key_buffer = extract_public_key_from_pem(temp_public_buffer);

        close_file(this->fp1);
        BIO_free(this->pub_bio);

        X509_free(this->cert);
        cout << "[Successfully utilized public data]" << endl;
    }

    return public_key_buffer;
}

string PemHandler::extract_public_key_from_pem(string pem_buffer)
{
    string pub_key_buffer = "(public-key ";
    pub_key_buffer += extract_public_modulus_from_pem(pem_buffer);
    pub_key_buffer += "))";

    return pub_key_buffer;
}

string PemHandler::extract_public_modulus_from_pem(string pem_buffer)
{
    string public_key_buffer, ex_pub;

    ex_pub = extract_public_exp_from_public_pem(pem_buffer);

    public_key_buffer = "(rsa (n #" +
        pem_buffer.substr(
            pem_buffer.find("Modulus")+7, 532) + "#)" +
            ex_pub;
    public_key_buffer.erase(remove(public_key_buffer.begin(), public_key_buffer.end(), '\n'), public_key_buffer.end());

    return public_key_buffer;
}

string PemHandler::extract_public_exp_from_public_pem(string pem_buffer)
{
    string ex_pub;
    ex_pub = pem_buffer.substr(pem_buffer.find("Exponent") + 14, 7);

    ex_pub.erase(remove(ex_pub.begin(), ex_pub.end(), 'x'), ex_pub.end());
    ex_pub = "(e #" + ex_pub + "#)";

    return ex_pub;
}
