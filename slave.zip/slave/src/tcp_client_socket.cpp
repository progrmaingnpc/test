#include "include/tcp_client_socket.h"

#ifdef _WIN32
    SOCKADDR_IN TcpClientBasics::specify_server_address(string server_ip_address)
    {
        SOCKADDR_IN server_address;
        server_address.sin_family = AF_INET;

        server_address.sin_port = htons(8443);
        cout << server_ip_address << endl;

        inet_pton(server_address.sin_family, server_ip_address.c_str(), &server_address.sin_addr);

        return server_address;
    }

#else
    sockaddr_in TcpClientBasics::specify_server_address(string server_ip_address)
    {
        sockaddr_in server_address;
        server_address.sin_family = AF_INET;

        cout << server_ip_address << endl;

        server_address.sin_port = htons(8443);
        inet_aton(server_ip_address.c_str(), &server_address.sin_addr);

        return server_address;
    }

#endif
