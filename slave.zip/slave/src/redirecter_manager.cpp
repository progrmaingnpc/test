#include "include/redirecter_manager.h"

void RedirecterManager::create_sessions()
{
    this->http_redirect_server.create_session(HTTP_PORT);
    this->https_redirect_server.create_session(HTTPS_PORT);
    this->https_redirect_server.create_ssl_context();
}

void RedirecterManager::redirecters_loop()
{
    for(int i = 0 ; i < 2 ; i ++) {
        activate_redirecters(i);
    }
}

void RedirecterManager::activate_redirecters(int socket_index)
{
    /* Handle connections */
    if(socket_index == 0) {
        this->https_redirect_server.select_fd();
        this->https_redirect_server.handle_client_connections();
    }
    else if(socket_index == 1) {
        this->http_redirect_server.select_fd();
        this->http_redirect_server.handle_client_connections();
    }
}

void RedirecterManager::close_sessions()
{
    this->https_redirect_server.close_server_socket();
    this->http_redirect_server.close_server_socket();
}
