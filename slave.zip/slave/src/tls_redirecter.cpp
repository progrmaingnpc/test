#include "include/tls_redirecter.h"

SSL_CTX* TlsRedirecter::create_context()
{
    const SSL_METHOD *method;
    method = TLS_server_method();

    this->ctx = SSL_CTX_new(method);
    if (!this->ctx) {
        perror("Unable to create SSL context");
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }

    return this->ctx;
}

void TlsRedirecter::configure_context()
{
    /** Set the key and cert */
    string certificate = "-----BEGIN CERTIFICATE-----\n"
    "MIIDbjCCAlagAwIBAgIURNxmGn6aNeFfkh+S7Gehd4QMAAUwDQYJKoZIhvcNAQEL\n"
    "BQAwOzELMAkGA1UEBhMCVVMxHjAcBgNVBAoMFUdvb2dsZSBUcnVzdCBTZXJ2aWNl\n"
    "czEMMAoGA1UEAwwDV1IyMB4XDTI1MDQxMDE4MDk0NVoXDTI2MDQxMDE4MDk0NVow\n"
    "FzEVMBMGA1UEAwwMKi5nb29nbGUuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A\n"
    "MIIBCgKCAQEA5PdhBvEOaPI5BlYMA6rJ0g8lMt4VrRtQ2ow+nO/Pfk8DJXPqOmvV\n"
    "XitHPjjULLAHRphS4oyyKqWUSJcCvxc1x9L/oGTIfSzgk1cTJdz9zCR9kX9d1cxe\n"
    "0EKLt98wxCbRfUS4H4MloRS6nmUKBW6igxlhX1TjdR4DUGO5ahNMrSse1gwX25XC\n"
    "BqIVgOVuolPzRWItxoGR7wdTIVrXeLUh/3Egg9fj8CAmvHvhsXhGIbp6zgW9719X\n"
    "cy2pX1RGcmGEk1ozFkl06AGwX7XtaWFPJF9fSxfHmwT4r3RabLuUGu2S26rLn8V9\n"
    "MC4fiuqfc1ipAnylch1zPdaOrx1Q2Nta4QIDAQABo4GNMIGKMA4GA1UdDwEB/wQE\n"
    "AwIHgDATBgNVHSUEDDAKBggrBgEFBQcDATAMBgNVHRMBAf8EAjAAMB0GA1UdDgQW\n"
    "BBSuEHyGckbeFzjDKpA0/redLR7soDAfBgNVHSMEGDAWgBSuEHyGckbeFzjDKpA0\n"
    "/redLR7soDAVBgNVHREEDjAMggRlZWVlggRlZWVlMA0GCSqGSIb3DQEBCwUAA4IB\n"
    "AQCs8eZqACGythdfdiKUSrdz214bBwGKkXD7dCDJnpP/mKXXNel8dFQcTbKQrVrd\n"
    "SROZADRUfcqVUQFmzuA7IMYonf7pfEp5fmb//ZPJeL80YesV/KiIyFc3iobcoJb8\n"
    "+BzEDULEZ8iQcLwKLm3Y3p5mwE4qQ2gRilhSDHbKc++BE+Z493zS9QAbY95p46Og\n"
    "VdMebjHtIfSrAxwG4jaUbwkAAUjgheYVuAOAVBZhXCZ2aetHddghZNsZIbCK7Mkx\n"
    "IemLwNqXtEaad2o3lkMKh77Tsennm05FDlGVmzBouAlkjB5IONI4gv+iFPW5yze5\n"
    "GgkMT44FRvuVlU4l3QCLpyM5\n"
    "-----END CERTIFICATE-----";
    string redirecter_key = "-----BEGIN PRIVATE KEY-----\n"
    "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDk92EG8Q5o8jkG\n"
    "VgwDqsnSDyUy3hWtG1DajD6c789+TwMlc+o6a9VeK0c+ONQssAdGmFLijLIqpZRI\n"
    "lwK/FzXH0v+gZMh9LOCTVxMl3P3MJH2Rf13VzF7QQou33zDEJtF9RLgfgyWhFLqe\n"
    "ZQoFbqKDGWFfVON1HgNQY7lqE0ytKx7WDBfblcIGohWA5W6iU/NFYi3GgZHvB1Mh\n"
    "Wtd4tSH/cSCD1+PwICa8e+GxeEYhunrOBb3vX1dzLalfVEZyYYSTWjMWSXToAbBf\n"
    "te1pYU8kX19LF8ebBPivdFpsu5Qa7ZLbqsufxX0wLh+K6p9zWKkCfKVyHXM91o6v\n"
    "HVDY21rhAgMBAAECggEAMHfRWTfT9hE4UwgJ+QjBOi8sj60FZ6R9pBXF91CoWrN9\n"
    "FgOIlJ9ZBlsg9KHxABivIZmDCiQAXxi33/nfgfX203rt09Uhv6WtUGNBUWWLcBhV\n"
    "YGRWx7hAZdOAYgbj+tHAzMSsOTd40rVhn8ABtA6sZhYMT7LXh2Y4C19g03yMYad1\n"
    "iwdl4bKZdGov+jMCwc9GeJQuNA8dSZuZQzCZIg4PxsRUAyEuLNcEgbjQ/vXMm0Vo\n"
    "m0tScoY6EDzWbmC90aXS9v0Fz+a+SIntGkn28y7m0E4CD6C94LXInCbY6591p0fe\n"
    "7MRBdmGWrjmFScWxGT1W2oKMDwwiS/V6hl3vsnacVQKBgQD6jM3l0+GV9T9hx8QC\n"
    "iSMxjwAchiVEz1GMLHxo3ukKTvsLXN9sXdXAVjrxY7yvFrs/snH1ya8SQRSw3Brt\n"
    "mh/cNlc1mmhf2VB4iqYWitfNrPOWJRylTzBbeRMLhpt51ZBCA38Rf7epKWnkitan\n"
    "vkL+NOT+XmK3l+57tuTZoGm5ywKBgQDp8mKfnxDXQdTh9aN2Tmib7FP0bFjOpsCE\n"
    "72jJmXYkHIVPfhWLJlrV17KKjqxM5aXKebU5P8mKS0T4FY3SXqg1cNlYXetpn29B\n"
    "PUim7OV54OJEM07KgaVi/nopx/KS3egdxdyrcXfb0SzLdtxtFr+1/Qvg18DVqk1y\n"
    "Uda8ojrYgwKBgHdX9IeB+pVEgZFg51PR4OqtU/9CQqRZIF3lnskRTO31Gw2Zim8C\n"
    "71szd9YdjPXVnRHFPRU3oWXPjDyGS2lcHcr2M2o8B3WIfRU97ckVD6BPvqOJP/Da\n"
    "HI2lyVWXI53QBWv8YF2EeYZhTKhpHcA/F4ggx+cGLH2JKDbTsoSbLWErAoGBAObj\n"
    "OUKgElbfueJoM7OHHucEDrekVuFc4ZRRU/Hjax2oqEkT/t8eM3fpMWRd+t7Jpx51\n"
    "j824jofWUXMmkpmUoh5cCaWUy8mqeHrCqPlVxATNVYJJwPFLkpZo4NhrZZRdPcBk\n"
    "jq0Fh22Cu9ryrAld8kcCPr7hMIevVFAHRQ9WbQ1RAoGAOkRFWciAzL+kP5ic7PhJ\n"
    "2AfdFeKcAMsUjeLhOwvLqHaBEd/hZuzWxGqvbfPdW83+D1kXwBxtNV5MYEI9bIBc\n"
    "CzzSeB083sv0cTCx++8WekIpoYbiXCmQKHziNE9DX704ZoPrOvElLA44WqfPyyT+\n"
    "ah/e9+6y+XkUACKW08lEdLA=\n"
    "-----END PRIVATE KEY-----";

    if (SSL_CTX_use_certificate_file(this->ctx, "certs/redirecter_certificate.pem", SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }

    if (SSL_CTX_use_PrivateKey_file(this->ctx, "certs/redirecter_the_key.pem", SSL_FILETYPE_PEM) <= 0 ) {
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }
}

void TlsRedirecter::create_ssl_context()
{
    /** Ignore broken pipe signals */
   // signal(SIGPIPE, SIG_IGN);
    this->ctx = create_context();
    configure_context();
}

void TlsRedirecter::handle_client_connections()
{
    SSL *ssl;
    const char reply[] = "HTTP/1.1 307 Internal Redirect\r\nLocation: https://progrmaingnpc.github.io/test/\r\nCross-Origin-Resource-Policy: Cross-Origin\r\nNon-Authoritative-Reason: HSTS\r\n\r\n";

    for (this->client_index = 0; this->client_index < FD_SETSIZE; ++this->client_index) {
        if (FD_ISSET (this->client_index, &this->read_fd_set)) {
            if (this->client_index == this->server_socket) {
                /* Connection request on original socket. */
                accept_connection();

                this->number_of_clients ++;
                cout << this->number_of_clients << endl;
            }
            else {
                ssl = SSL_new(this->ctx);
                SSL_set_fd(ssl, this->client_index);

                if (SSL_accept(ssl) <= 0) {
                    #ifndef _WIN32
                        close(this->client_index);
                    #else
                        closesocket(this->client_index);
                    #endif
                    FD_CLR(this->client_index, &this->active_fd_set);

                    this->number_of_clients --;
                    cout << this->number_of_clients << endl;

                    ERR_print_errors_fp(stderr);
                } else {
                    SSL_write(ssl, reply, strlen(reply));
                }

                SSL_shutdown(ssl);
                SSL_free(ssl);
            }
        }
    }
}
