#include "include/tls_client.h"

#ifndef _WIN32
    int TlsClient::create_socket_object()
    {
        this->client_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (this->client_socket == -1) {
            perror("create socket");
        }
        return this->client_socket;
    }
#else
    SOCKET TlsClient::create_socket_object()
    {
        this->client_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (this->client_socket== INVALID_SOCKET) {
            wprintf(L"socket function failed with error: %ld\n", WSAGetLastError());
            WSACleanup();
        }
        return this->client_socket;
    }
#endif
void TlsClient::connect_to_server()
{
    #ifdef _WIN32
        if (connect(this->client_socket, (SOCKADDR *)&this->server_address, this->length_of_address) == SOCKET_ERROR) {
            wprintf(L"connect function failed with error: %ld\n", WSAGetLastError());
            this->iResult = closesocket(this->client_socket);

            if (this->iResult == SOCKET_ERROR)
                wprintf(L"closesocket function failed with error: %ld\n", WSAGetLastError());

            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        if (connect(this->client_socket, (struct sockaddr*)&this->server_address, this->length_of_address)) {
            perror("connect");
            exit(EXIT_FAILURE);
        }
    #endif
}

SSL_CTX* TlsClient::create_context()
{
    const SSL_METHOD *method;
    method = TLS_client_method();
    this->ctx = SSL_CTX_new(method);

    if (!this->ctx) {
        perror("Unable to create SSL context");
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }

    return this->ctx;
}

void TlsClient::configure_ssl_context()
{
    int sock;
    SSL_library_init();
    SSLeay_add_ssl_algorithms();

    SSL_load_error_strings();
    this->ctx = create_context();
    this->ssl = SSL_new(this->ctx);

    if (!this->ssl) {
        char *str = ERR_error_string(ERR_get_error(), 0);
        cout << "huh??" << str << endl;
        exit(EXIT_FAILURE);
    }

    sock = SSL_get_fd(this->ssl);
    SSL_set_fd(this->ssl, this->client_socket);

    int err = SSL_connect(this->ssl);
    cout << sock << endl;

    if (err != 1) {
        printf("Error creating SSL connection.  err=%x\n", err);
        char *str = ERR_error_string(ERR_get_error(), 0);

        cout << str << " " << endl;
        fflush(stdout);

        exit(EXIT_FAILURE);
    }
    printf ("SSL connection using %s\n", SSL_get_cipher(this->ssl));
}

void TlsClient::close_connection()
{
    SSL_shutdown(this->ssl);
    SSL_free(this->ssl);

    #ifdef _WIN32
        perror("unexepected disconnect");
        this->iResult = closesocket(this->client_socket);

        if (iResult == SOCKET_ERROR) {
            wprintf(L"closesocket function failed with error: %ld\n", WSAGetLastError());
            WSACleanup();
            exit(EXIT_FAILURE);
        }
        WSACleanup();
    #else
        perror("unexepected disconnect");
        close(this->client_socket);
    #endif
}

void TlsClient::create_session(string server_ip_address)
{
    this->server_address = specify_server_address(server_ip_address);
    this->length_of_address = sizeof(this->server_address);

    #ifndef _WIN32
        int copy = create_socket_object();
        if(copy == -1) {
            exit(-1);
        }
    #else
        SOCKET copy = create_socket_object();
        if(copy == INVALID_SOCKET) {
            exit(-1);
        }
    #endif
    cout << "Successfully created tls client socket" << endl;

    connect_to_server();
    configure_ssl_context();
}
