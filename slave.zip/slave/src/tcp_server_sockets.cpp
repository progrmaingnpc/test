#include "include/tcp_server_sockets.h"

#ifndef _WIN32
    sockaddr_in TcpServerBasics::specify_server_address(int port)
    {
        sockaddr_in server_address;
        server_address.sin_family = AF_INET;

        server_address.sin_port = htons(port);
        server_address.sin_addr.s_addr = htonl(INADDR_ANY);

        return server_address;
    }
#else
    SOCKADDR_IN TcpServerBasics::specify_server_address(int port)
    {
        SOCKADDR_IN server_address;
        server_address.sin_family = AF_INET;

        server_address.sin_port = htons(port);
        server_address.sin_addr.s_addr = htonl(INADDR_ANY);

        return server_address;
    }
#endif
