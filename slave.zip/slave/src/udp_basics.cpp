#include "include/udp_basics.h"

#ifdef _WIN32
    SOCKADDR_IN UdpBasics::specify_server_address(string server_ip_address)
    {
       // string eee = "192.168.122.48";
        SOCKADDR_IN server_address;

        memset(&server_address, 0, sizeof(server_address));
        server_address.sin_family = AF_INET;

        server_address.sin_port = htons(PORT);
        server_address.sin_addr.s_addr = htonl(INADDR_ANY);

        inet_pton(server_address.sin_family, server_ip_address.c_str(), &server_address.sin_addr);

        return server_address;
    }
#else
    sockaddr_in UdpBasics::specify_server_address(string server_ip_address)
    {
      //  string eee = "192.168.122.48";
        sockaddr_in server_address;

        memset(&server_address, 0, sizeof(server_address));
        server_address.sin_family = AF_INET;

        server_address.sin_port = htons(PORT);
        server_address.sin_addr.s_addr = htonl(INADDR_ANY);

        inet_aton(server_ip_address.c_str(), &server_address.sin_addr);

        return server_address;
    }
#endif
