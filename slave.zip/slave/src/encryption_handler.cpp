#include "include/encryption_handler.h"

void EncryptionHandler::die(const char *format, ...)
{
    /*
        * A variadic function, whic prints the error before exiting the code
        * format - used as the output stream format for error
    */

    /*
        * variadic function:  A function which takes a variable number (as many as received) of arguments
        * that is why ... is an argument in this function, this means this is a variadic function
    */

    /* Defines a list of arguments */
    va_list arg_ptr;
    /* Gives local varaibles of this functions access to the variadic arguments  (format and what is in ...) */
    va_start(arg_ptr, format);
    /* Prints the variadic argument list */
    vfprintf(stderr, format, arg_ptr);
    cout << "[hmmmm]" << endl;
    /* Stops the traversal of variadic function arguments */
    va_end(arg_ptr);
    /* dummy proof (You must add \n, it MUST LOOK GOOD) */
    if (*format && format[strlen(format) - 1] != '\n') {
        putc('\n', stderr);
    }
}

void EncryptionHandler::show_sexp(const char *prefix, gcry_sexp_t a)
{
    /*
        * Prints the SExpression data
        * It is beautiful
        * So what do we see in the SExpression object of the key?
            * 1. n - Public key
            * 2. e - RSA public exponent e (it is commonly 17 = 0x10001 = 010001).
            * 3. d - Private key
            * 4. q - Secret prime number used in creating the key
            * 5. p - Secret prime number (p<q) used in creating the key
            * 6. u - Multiplicative inverse u = p^{-1} \bmod q.
        * source: https://www.gnupg.org/documentation/manuals/gcrypt/RSA-key-parameters.html#RSA-key-parameters
    */
    char *buf;
    size_t size;

    if (prefix){
        fputs(prefix, stderr);
    }
    size = gcry_sexp_sprint(a, GCRYSEXP_FMT_ADVANCED, NULL, 0);
    buf = (char *)gcry_xmalloc(size);

    gcry_sexp_sprint(a, GCRYSEXP_FMT_ADVANCED, buf, size);
    fprintf(stderr, "%.*s", (int) size, buf);
    gcry_free(buf);
}

string EncryptionHandler::sexp_to_string(gcry_sexp_t sexp)
{
    char *buf;
    size_t size;

    string data_buffer;
    size = gcry_sexp_sprint(sexp, GCRYSEXP_FMT_ADVANCED, NULL, 0);

    buf = (char *)gcry_xmalloc(size);
    gcry_sexp_sprint(sexp, GCRYSEXP_FMT_ADVANCED, buf, size);

    data_buffer = buf;
    gcry_free(buf);

    return data_buffer;
}

gcry_sexp_t EncryptionHandler::string_to_sexp(string str_buffer)
{
    int rc;
    gcry_sexp_t new_sexp;

    rc = gcry_sexp_new(&new_sexp, str_buffer.c_str(), 0, 1);

    if (rc) {
        die("error creating S-expression: %s\n", gcry_strerror(rc));
        return NULL;
    }

    return new_sexp;
}

void EncryptionHandler::make_rsa_key_pair()
{
    //-------------------------------------------------------------------
    // Generate Key
    //-------------------------------------------------------------------
    int rc;
    gcry_sexp_t key_spec;

    rc = gcry_sexp_new(&key_spec, "(genkey (rsa (nbits 4:2048)))", 0, 1);
    if (rc) {
        die("error creating S-expression: %s\n", gcry_strerror(rc));
    }

    //>> Generate key
    rc = gcry_pk_genkey(&this->key, key_spec);
    gcry_sexp_release(key_spec);

    if (rc) {
        die("error generating RSA key: %s\n", gcry_strerror(rc));
    }
    show_sexp("[Key pair]:\n", this->key);
}

void EncryptionHandler::create_personal_private_key()
{
    /* Create private key object the proceses's personal key pair */
    this->priv_key = gcry_sexp_find_token(this->key, "private-key", 0);

    if (!this->priv_key) {
        die("private part missing in key\n");
    }

    show_sexp("[Private key]:\n", this->priv_key);
}

void EncryptionHandler::create_personal_private_key(string priv_buffer)
{
    /* Create private key object the proceses's personal key pair */
    int rc;
    rc = gcry_sexp_new(&this->priv_key, priv_buffer.c_str(), 0, 1);

    if (rc) {
        die("Private part missing: %s\n", gcry_strerror(rc));
    }

    show_sexp("[Private key]:\n", this->priv_key);
}

void EncryptionHandler::create_personal_public_key()
{
    /* Create public key object the proceses's personal key pair */
    this->personal_pub_key = gcry_sexp_find_token(this->key, "public-key", 0);

    if (!this->personal_pub_key) {
        die("public part missing in key\n");
    }

    show_sexp("[Personal Public key]:\n", this->personal_pub_key);
}

void EncryptionHandler::create_personal_public_key(string public_buffer)
{
    /* Create public key object the proceses's personal key pair */
    int rc;
    rc = gcry_sexp_new(&this->personal_pub_key, public_buffer.c_str(), 0, 1);

    if (rc) {
        die("Public part missing: %s\n", gcry_strerror(rc));
    }

    show_sexp("[Personal Public key]:\n", this->personal_pub_key);
}

gcry_sexp_t EncryptionHandler::extract_public_key(string key_data)
{
    /* Create public key object with the data the server sent */
    int rc;

    rc = gcry_sexp_new(&this->server_pub_key, key_data.c_str(), 0, 1);

    if (rc) {
        die("error creating S-expression: %s\n", gcry_strerror(rc));
    }

    show_sexp("[Server's Public key]:\n", this->server_pub_key);
    return this->server_pub_key;
}

gcry_sexp_t EncryptionHandler::create_plain_text_object(string data)
{
    /* Create plain-text object */
    int rc;
    gcry_sexp_t plain;

    rc = gcry_sexp_build(&plain, NULL, "(data (flags raw) (value %s))", data.c_str());

    if (rc) {
        die("converting data for encryption failed: %s\n", gcry_strerror(rc));
    }

   // show_sexp("[Plaintext data]:\n", plain);
    return plain;
}

gcry_sexp_t EncryptionHandler::sign_data(gcry_sexp_t cipher, gcry_sexp_t private_key)
{
    /*  Encrypt data */
    int rc;
    gcry_sexp_t signed_data;

    rc = gcry_pk_sign(&signed_data, cipher, private_key);

    if (rc) {
        die("signing failed: %s\n", gcry_strerror(rc));
    }

    show_sexp("[Data signed by the server]:\n", signed_data);
    return signed_data;
}

int EncryptionHandler::verify_data(gcry_sexp_t cipher, gcry_sexp_t signed_data)
{
    /*  Encrypt data */
    int rc;
 //   gcry_error_t m;
   // gcry_pk_ctl(int cmd, void *buffer, size_t buflen)
    rc = gcry_pk_verify(signed_data, cipher, this->personal_pub_key);

    if(rc) {
      //  die("[Verifiction Failed]: %s\n", gcry_strerror(rc));
        cout << "[Verifiction Failed]: " << gcry_strerror(rc) << endl;
        return -1;
    } else {
        show_sexp("[The signature was successfully verified! This was signed by a trusted CA]:\n", cipher);
    }
    return 0;
}


gcry_sexp_t EncryptionHandler::encrypt_data(gcry_sexp_t plain, gcry_sexp_t pub_key)
{
    /*  Encrypt data */
    int rc;
    gcry_sexp_t c_cipher;

    rc = gcry_pk_encrypt(&c_cipher, plain, pub_key);

    if (rc) {
        die("encryption failed: %s\n", gcry_strerror(rc));
    }

   // show_sexp("[Data encrypted by the client]:\n", c_cipher);
    return c_cipher;
}

gcry_sexp_t EncryptionHandler::decrypt_data(gcry_sexp_t cipher, gcry_sexp_t private_key)
{
    int rc;
    gcry_sexp_t decrypted;

    rc = gcry_pk_decrypt(&decrypted, cipher, private_key);

    if (rc) {
        die("decryption failed: %s\n", gcry_strerror(rc));
        return NULL;
    }

    show_sexp("[Unencrypted data]:\n", decrypted);
    return decrypted;
}

void EncryptionHandler::print_crypt_from_list(gcry_sexp_t cipher)
{
    /* Print encrypted data as a plain unsigned char buffer */
    gcry_sexp_t data_list;
    size_t len;

    data_list = gcry_sexp_find_token(cipher, "a", 0);

    const char *data = gcry_sexp_nth_data(data_list, 1, &len);
    printf("The encrypted data:\n");

    for (int i = 0; i < (int)len; i++) {
        printf("%02x", (unsigned char) data[i]);
    }
    printf("\n");
}

gcry_sexp_t EncryptionHandler::randomize_integer_data(int nbits_data)
{
    /* Randomize data */
    int rc;
    gcry_mpi_t x;
    gcry_sexp_t plain;

    x = gcry_mpi_new(nbits_data);
   // gcry_mpi_randomize(x, nbits_data, GCRY_WEAK_RANDOM); // <-- whoever put this(GCRY_WEAK_RANDOM) is a troll

    gcry_mpi_randomize(x, nbits_data, GCRY_VERY_STRONG_RANDOM);
    rc = gcry_sexp_build(&plain, NULL, "(data (flags raw) (value %s))", x);

    if (rc) {
        die("converting data for encryption failed: %s\n", gcry_strerror(rc));
    }

    return plain;
}
