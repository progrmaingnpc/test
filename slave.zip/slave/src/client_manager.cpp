#include "include/client_manager.h"

void ClientManager::create_sessions(string server_ip_address)
{
    this->tls_client.create_session(server_ip_address);
    this->udp_client.create_session(server_ip_address);
}

void ClientManager::activate_socket(int socket_index)
{
    /* Handle connections */
    if(socket_index == 0) {
       this->tls_client.send_message();
    }
    else if(socket_index == 1) {
       this->udp_client.keep_session();
    }
}

void ClientManager::main_manager_loop()
{
    while(TRUE) {
        for(int i = 0 ; i < 2 ; i ++){
            activate_socket(i);

            #ifdef _WIN32
                Sleep(20); // Sleep takes milliseconds on Windows
            #else
                sleep(2);    // sleep takes seconds on UNIX-like systems
            #endif
        }
    }
}

void ClientManager::close_sessions()
{
    this->udp_client.close_socket();
    this->tls_client.close_connection();
}
