#include "include/client_runner.h"

int main()
{
    #ifdef _WIN32
        int iResult;
        WSADATA wsaData;
        iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
        if (iResult != NO_ERROR) {
            wprintf(L"Error at WSAStartup()\n");
            return -1;
        }
        cout << iResult << endl;
    #endif
    VeryKindClient nice_guy;
    RedirecterManager redirecter;
    ClientManager client_manager;

    redirecter.create_sessions();
    nice_guy.boot_system(client_manager, redirecter);

    redirecter.close_sessions();
    cout << "I am a kind client, Hello There!ee" << endl;

    return 0;
}
