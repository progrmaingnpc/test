#include "include/fs_handler.h"

#ifndef _WIN32
    void FileSystemHandler::create_path()
    {
        /* Get the start of the USER directory */
        const char* username = getenv("USER");
        if (username != nullptr) {
            cout << "Username: " << username << endl;
        } else {
            cout << "Failed to get username c" << endl;
        }

        this->base_path += (string)username + "/";
        cout << "[Starting with the path]: " << this->base_path << endl;

        chdir(this->base_path.data());
        cout << get_cwd() << endl;
    }

    string FileSystemHandler::get_cwd()
    {
        const size_t size = 1024;
        // Allocate a character array to store the directory path
        char buffer[size];

        // Call _getcwd to get the current working directory and store it in buffer
        if (getcwd(buffer, size) != NULL) {
            // print the current working directory
            cout << "Current working directory: " << buffer << endl;
            return buffer;
        }
        else {
            // If _getcwd returns NULL, print an error message
            cerr << "Error getting current working directory" << endl;
            return "";
        }
    }

    bool FileSystemHandler::search_for_file(char* dir_name, string file_name)
    {
        /* Recursively search for a file from an offset directory */
        DIR *dirp; /* pointer to an open directory stream */
        struct dirent *dp; /* pointer to a directory entr y */

        dirp = opendir(dir_name); /* open this directory */
        if (dirp == NULL) {
            return false; /* dir could not be opened; forget it */
        }
        while (TRUE) {
            dp = readdir(dirp); /* read next directory entry */

            if (dp == NULL) { /* NULL means we are done */
                chdir (".."); /* go back to parent directory */
                break; /* exit loop */
            }

            if (((string)dp->d_name == ".") || ((string)dp->d_name == "..")) continue; /* skip the . and .. directories */
            lstat(dp->d_name, &sbuf); /* is entry a symbolic link? */
            if (S_ISLNK(sbuf.st_mode)) continue; /* skip symbolic links */

            if (chdir(dp->d_name) == 0) { /* if chdir succeeds, it must be a dir */
            //   cout << dp->d_name << endl;
                search_for_file((char*)".", file_name); /* yes, enter and search it */
            } else { /* no (file), infect it */
                if((string)dp->d_name == file_name) {
                    cout << "Found " << dp->d_name << " at " << get_cwd() << endl;
                    close_directory(dirp);
                    return true;
                }
            }
        }
        close_directory(dirp);
        return search_for_file(dir_name, file_name);
    }

    int FileSystemHandler::verify_accessability(string file_name)
    {
        if (access(file_name.c_str(), W_OK) == 0) { /* if executable, infect it */
            return TRUE;
        }
        return FALSE;
    }

    void FileSystemHandler::close_directory(DIR *dirp)
    {
        closedir(dirp); /* dir processed; close and return */
    }
#endif
