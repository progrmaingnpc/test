#include "include/windows_sucks.h"

int WindowsWeirdApi::create_wsa_thing()
{
    #ifdef _WIN32
        WSADATA wsaData;
        this->iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
        if (this->iResult != NO_ERROR) {
            wprintf(L"Error at WSAStartup()\n");
            return -1;
        }
        return this->iResult;
    #endif

    return 0;
}
