#include "include/udp_client.h"

void UdpClient::create_socket_object()
{
    #ifdef _WIN32
        this->client_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

        if (this->client_socket  == INVALID_SOCKET) {
            wprintf(L"socket function failed with error: %ld\n", WSAGetLastError());
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        this->client_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (this->client_socket < 0) {
            perror("Unable to create socket");
            exit(EXIT_FAILURE);
        }
    #endif

}

void UdpClient::set_timout()
{
    this->timeout.tv_sec = 0;
    this->timeout.tv_usec = 5;

    #ifdef _WIN32
        int a = 1;
        if (setsockopt(this->client_socket, SOL_SOCKET, SO_RCVBUF, (char *)&a, sizeof(a)) < 0) {
            cout << "[Failed to set socket timeout]" << endl;
            exit(EXIT_FAILURE);
        }
        if (setsockopt(this->client_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&a, sizeof(a)) < 0) {
            cout << "[Failed to make socket reusable]" << endl;
            exit(EXIT_FAILURE);
        }
    #else
        if (setsockopt(this->client_socket, SOL_SOCKET, SO_RCVTIMEO, &this->timeout, sizeof(this->timeout)) < 0) {
            cout << "[Failed to set socket timeout]" << endl;
            exit(EXIT_FAILURE);
        }
        if (setsockopt(this->client_socket, SOL_SOCKET, SO_REUSEADDR, &this->timeout, sizeof(this->timeout)) < 0) {
            cout << "[Failed to make socket reusable]" << endl;
            exit(EXIT_FAILURE);
        }
    #endif
}

void UdpClient::keep_session()
{
    /* Data arriving on an already-connected socket. */

    cout << "hmmmmmmm " << inet_ntoa(this->server_address.sin_addr) << endl;
    if(send_message() < 0) {
        close_socket();
        perror ("closed after send response");
    }
    else if (receive_message() < 0) {
        close_socket();
        perror ("closed after recieve");
    }

}

int UdpClient::send_message()
{
    char redirect_message[] = "no";

    #ifdef _WIN32
        this->iResult = sendto(this->client_socket,
                       (char *)redirect_message, strlen(redirect_message),
                       0, (SOCKADDR *)&this->server_address, this->length_of_address);
        if (this->iResult == SOCKET_ERROR) {
            wprintf(L"sendto failed with error: %d\n", WSAGetLastError());
            closesocket(this->client_socket);
            WSACleanup();
            return -1;
        }
    #else
        ssize_t sent;
        sent = sendto(this->client_socket, (char *)redirect_message, strlen(redirect_message),
                    MSG_CONFIRM, (const struct sockaddr *) &this->server_address,
                    this->length_of_address);
        if(sent < 0) {
            /* Send error. */
            perror ("send");
            return -1;
        }
        else {
            /* Data write. */
            cout << "[Data has been successfully sent to the server]" << endl;
            return 0;
        }
    #endif
    return 0;
}

int UdpClient::receive_message()
{
    #ifdef _WIN32
        int iResult;
        char RecvBuf[1024];
        int BufLen = 1024;

        iResult = recvfrom(this->client_socket,
                           RecvBuf, BufLen, 0, (SOCKADDR *) &this->server_address, &this->length_of_address);
        if (iResult == SOCKET_ERROR) {
            wprintf(L"recvfrom failed with error %d\n", WSAGetLastError());
            return -1;
        }
        cout << RecvBuf << endl;
        return 0;

    #else
        ssize_t nbytes;
        nbytes = recvfrom(this->client_socket, (char *)this->message_buffer, 1024,
                        MSG_WAITALL, (struct sockaddr *) &this->server_address,
                        &this->length_of_address);
        if (nbytes < 0){
            /* Read error. */
            perror ("read");
            return -2;
        }
        else if (nbytes == 0){
            /* End-of-file. */
            perror ("read");
            return -1;
        }
        else
        {
            /* Data read. */
            fprintf (stderr, "Server: sent message: `%s'\n", this->message_buffer);
            return 0;
        }
    #endif
    return 0;
}

void UdpClient::close_socket()
{
    #ifdef _WIN32
        closesocket(this->client_socket); // Sleep takes milliseconds on Windows
        WSACleanup();
    #else
        close(this->client_socket);    // sleep takes seconds on UNIX-like systems
    #endif
}

void UdpClient::create_session(string server_ip_address)
{
    this->server_address = specify_server_address(server_ip_address);
    this->length_of_address = sizeof(this->server_address);

    create_socket_object();
    set_timout();
}
