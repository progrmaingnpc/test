#ifndef KNOWN_VALUES_H
#define KNOWN_VALUES_H

//It has to be at the start, overwise seg fault when compiling for linux
    //Other wise comemnt this line to compile for linux
#define WIN32_LEAN_AND_MEAN
//It has to be in this, order overwise seg fault when compiling for windows
#ifdef _WIN32
    // Windows-specific declaration
    #define WIN32_LEAN_AND_MEAN
    #ifndef UNICODE
    #define UNICODE
    #endif
    #include <stdio.h>
    #include <windows.h>  // For Windows
    #include <string>
    #include <cstring>
    #include <winsock2.h>
    #include <ws2tcpip.h> // for other useful socket functions like inet_pton, etc.
    #include <ws2ipdef.h>
    #include <iphlpapi.h>
    #include <iostream>
    #include <iomanip>
    #include <inaddr.h>
    #include <filesystem>
    #include <iptypes.h>
    #define MSG_CONFIRM 0x800
    #define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x))
    #define FREE(x) HeapFree(GetProcessHeap(), 0, (x))
#else
    // Linux-specific declaration
    #define WIN32_LEAN_AND_MEAN
    #include <stdio.h>
    #include <unistd.h>      // For Linux
    #include <sys/socket.h>  // Unix/Linux socket headers
    #include <netinet/in.h>   // for sockaddr_in
    #include <arpa/inet.h>    // for inet_pton
    #include <netdb.h>        // for gethostbyname
    #include <sys/types.h>
    #include <net/if.h>
    #include <string>
    #include <cstring>
    #include <iostream>
    #include <iomanip>
    #include <sys/types.h>
    #include <sys/select.h>
    #include <bits/types/struct_timeval.h>
    #include <endian.h>
    #include <filesystem>
    #include <bits/stdc++.h>
    using std::filesystem::path;
#endif

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rsa.h>
#include <openssl/crypto.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/bioerr.h>
#include <openssl/conf.h>
#include <openssl/x509v3.h>
#include <openssl/bn.h>
#include <openssl/asn1.h>
#include <openssl/x509.h>
#include <openssl/x509_vfy.h>
#include <openssl/ossl_typ.h>
#include <openssl/evp.h>
#include <openssl/decoder.h>
#include <openssl/encoder.h>
#include <openssl/bn.h>
#include <openssl/sha.h>
#include <pcapplusplus/ProtocolType.h>
#include <pcapplusplus/PcapLiveDevice.h>
#include <pcapplusplus/RawPacket.h>
#include <pcapplusplus/Packet.h>
#include <pcapplusplus/SystemUtils.h>
#include <pcapplusplus/EthLayer.h>
#include <pcapplusplus/IPv4Layer.h>
#include <pcapplusplus/IPv6Layer.h>
#include <pcapplusplus/TcpLayer.h>
#include <pcapplusplus/UdpLayer.h>
#include <pcapplusplus/DnsLayer.h>
#include <pcapplusplus/DnsLayerEnums.h>
#include <pcapplusplus/DnsResource.h>
#include <pcapplusplus/DnsResourceData.h>
#include <pcapplusplus/PcapFileDevice.h>
#include <pcapplusplus/MacAddress.h>
#include <pcapplusplus/IpAddress.h>
#include <pcapplusplus/IcmpLayer.h>
#include <pcapplusplus/ArpLayer.h>
#include <pcapplusplus/PcapFilter.h>
#include <pcapplusplus/PcapLiveDeviceList.h>
#include <pcapplusplus/SystemUtils.h>
#include <pcapplusplus/Device.h>
#include <pcapplusplus/Logger.h>
#include <pcapplusplus/NetworkUtils.h>
#include <exception>
#include <stdexcept>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <cstring>
#include <cassert>
#include <iostream>
#include <thread>
#include <mutex>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <sstream>
#include <locale>
#include <ctime>
#include <time.h>
#include <limits>
#include <future>
#include <chrono>
#include <algorithm>
#include <functional>
#include <format>
#include <thread>
#include <gcrypt.h>

#ifndef TRUE
    #define TRUE 1
#endif

#ifndef FALSE
    #define FALSE 0
#endif

using pcpp::SRC;
using pcpp::DST;
using pcpp::IP;
using pcpp::ARP;
using pcpp::ICMP;
using pcpp::DNS;
using pcpp::ARP_REPLY;
using pcpp::ARP_REQUEST;
using pcpp::DNS_TYPE_A;
using pcpp::DNS_TYPE_AAAA;
using pcpp::RawPacket;
using pcpp::Packet;
using pcpp::PcapLiveDevice;
using pcpp::PcapLiveDeviceList;
using pcpp::ProtocolType;
using pcpp::ProtoFilter;
using pcpp::GeneralFilter;
using pcpp::OrFilter;
using pcpp::NotFilter;
using pcpp::MacAddressFilter;
using pcpp::IPFilter;
using pcpp::Ethernet;
using pcpp::EthLayer;
using pcpp::IPLayer;
using pcpp::IPv4Layer;
using pcpp::IPv6Layer;
using pcpp::IcmpLayer;
using pcpp::ArpLayer;
using pcpp::UdpLayer;
using pcpp::DnsLayer;
using pcpp::DnsOverTcpLayer;
using pcpp::IPv4Address;
using pcpp::IPv6Address;
using pcpp::IPv4DnsResourceData;
using pcpp::IPv6DnsResourceData;
using pcpp::IPNetwork;
using pcpp::MacAddress;
using pcpp::DnsQuery;
using pcpp::DnsResource;
using pcpp::Logger;
using pcpp::ArpOpcode;
using pcpp::NetworkUtils;


using std::string;
using std::cout;
using std::endl;
using std::atomic;
using std::mutex;
using std::vector;
using std::stringstream;
using std::hex;
using std::tuple;
using std::this_thread::sleep_for;
using std::cerr;
using std::hash;
using std::cin;
using std::lock_guard;
using std::logic_error;
using std::flush;
using std::to_string;
using std::fill;
using std::array;
using std::exception;
using std::thread;
using std::get;
typedef size_t Type;
/**
 * A struct for collecting packet statistics
 */

struct key_data {
    gcry_sexp_t key;
    string key_buffer;
};

struct device_identifier {

    atomic<bool> answered[2] = { false, false };
    string device_name;
    string ipv4_address;
    string ipv6_address;
    string mac_address;

    void clean() {
        fill(begin(answered), end(answered), false);
        device_name.clear();
        ipv4_address.clear();
        ipv6_address.clear();
        mac_address.clear();
    };
};

struct PacketStats
{
    int icmpPacketCount = 0;
    int arpPacketCount = 0;
    string src_mac_address = "00:00:00:00:00:00";
    string user_src_ip = "0.0.0.0";
    string search_ip;
    /**
     * Clear all stats
     */
    void clear() {
        icmpPacketCount = arpPacketCount = 0;
        src_mac_address = "00:00:00:00:00:00";
        user_src_ip = "0.0.0.0";
    }

    // Constructor is optional here since the members are already initialized
    PacketStats() = default;

    /**
     * Collect stats from a packet
     */

    void consumePacket(Packet& packet)
    {
        if(packet.isPacketOfType(ARP)) {
            arpPacketCount++;
        }
        else if(packet.isPacketOfType(ICMP)) {
            icmpPacketCount++;
        }
    }

    /**
     * Print stats to console
     */
    void printToConsole()
    {
        cout << "[ICMP packet count]: " << icmpPacketCount <<
        endl << "[ARP. packet count]: " << arpPacketCount <<
        endl;
    }
};

struct networkdata {

    string network_mac;
    string default_gateway;
    string my_ipv6;
    string my_ip;
    string my_mac;
    string target_ipv4;
    string target_mac;
    string target_ipv6;
    string hashed_message;
    key_data private_key;
    key_data public_key;
    string domains_for_responses[12] = {
        "edge-http.microsoft.com", "detectportal.firefox.com",
        "www.bing.com", "detectportal.brave-http-only.com",
        "search.brave.com", "google.", "gstatic",
        "dns", "doh", "adblock", "one.one.one.one", "tunnel."};
    vector<string> recently_spoofed;
    vector<tuple<string,string>> potential_users; // Stores ip address and the mac address of devices conencted to the network
    vector<string> online_macs; // Stores mac address of active devices which have the client running
    vector<tuple<string,string>> unhandled_users; // Stores mac address and hash of active devices which have the client running
    device_identifier user_device;
    PacketStats stats;
    int counter = 0;
    int previous_counter;
    atomic<bool> spoof_switch = false;
    tuple<string,string> master_address;

    string (*hasher6969)(string) = hash_creator;
    RawPacket (*answers_analyzer)(RawPacket*, string[2], RawPacket(*[3])(RawPacket*, string[2])) = dns_answers_analysis;
    RawPacket (*forgerers[3])(RawPacket*, string[2]) = { dns_forge_A, dns_forge_Auth, dns_forge_Add };

    RawPacket (*verifier)(RawPacket*, string[7], atomic<bool>[2], RawPacket (*[2])(RawPacket*, string[7], atomic<bool>[2])) = icmp_analysis;
    RawPacket (*analyzers[2])(RawPacket*, string[7], atomic<bool>[2]) = { response_analysis, request_analysis };

    static string hash_creator(string message)
    {
        EVP_MD_CTX *ctx;

        if((ctx = EVP_MD_CTX_create()) == NULL)
            cout << "no" << endl;

        if(1 != EVP_DigestInit_ex(ctx, EVP_sha256(), NULL))
            cout << "no" << endl;

        if(1 != EVP_DigestUpdate(ctx, message.data(), message.length()))
            cout << "no" << endl;

        unsigned char digest[EVP_MAX_MD_SIZE];
        unsigned int digest_len = sizeof(digest);

        if(1 != EVP_DigestFinal_ex(ctx, digest, &digest_len))
            cout << "no" << endl;

        std::stringstream ss;
        ss << std::hex << std::setfill('0');
        for (size_t i = 0; i < digest_len; ++i) {
            ss << std::setw(2) << static_cast<int>(digest[i]);
        }
        string hash_string = ss.str();
     //   cout << "brand new" << hash_string << endl;

        EVP_MD_CTX_destroy(ctx);

        return hash_string;
    }

    static RawPacket dns_answers_analysis(RawPacket* pack, string ips[2],  RawPacket (*forgerers[3])(RawPacket*, string[2]))
    {
        RawPacket package;
        for(int i = 0 ; i < 3 ; i ++) {
            package = forgerers[i](pack, ips);
        }

        return package;
    }

    static RawPacket dns_forge_A(RawPacket* pack, string ips[2])
    {
        Packet dnsPacket(pack);
        IPv4Address ip4 = ips[0];
        IPv6Address ip6 = ips[1];

        IPv4DnsResourceData dns_v4_data(ip4);
        IPv6DnsResourceData dns_v6_data(ip6);

        DnsLayer* dnsLayer = dnsPacket.getLayerOfType<DnsLayer>();
        DnsResource* response_pointer = dnsLayer->getFirstAnswer();

        for(int i = 0 ; i < (int)dnsLayer->getAnswerCount() ; i ++) {

            if(response_pointer->getDnsType() == DNS_TYPE_A) {
                response_pointer->setData(&dns_v4_data);
            }
            else if(response_pointer->getDnsType() == DNS_TYPE_AAAA) {
                response_pointer->setData(&dns_v6_data);
            }

            response_pointer = dnsLayer->getNextAnswer(response_pointer);
        }

        return *dnsPacket.getRawPacket();
    }

    static RawPacket dns_forge_Auth(RawPacket* pack, string ips[2])
    {
        Packet dnsPacket(pack);
        IPv4Address ip4 = ips[0];
        IPv6Address ip6 = ips[1];

        IPv4DnsResourceData dns_v4_data(ip4);
        IPv6DnsResourceData dns_v6_data(ip6);

        DnsLayer* dnsLayer = dnsPacket.getLayerOfType<DnsLayer>();
        DnsResource* response_pointer = dnsLayer->getFirstAuthority();

        for(int i = 0 ; i < (int)dnsLayer->getAuthorityCount() ; i ++) {

            if(response_pointer->getDnsType() == DNS_TYPE_A) {
                response_pointer->setData(&dns_v4_data);
            }
            else if(response_pointer->getDnsType() == DNS_TYPE_AAAA) {
                response_pointer->setData(&dns_v6_data);
            }

            response_pointer = dnsLayer->getNextAuthority(response_pointer);
        }

        return *dnsPacket.getRawPacket();
    }

    static RawPacket dns_forge_Add(RawPacket* pack, string ips[2])
    {
        Packet dnsPacket(pack);
        IPv4Address ip4 = ips[0];
        IPv6Address ip6 = ips[1];

        IPv4DnsResourceData dns_v4_data(ip4);
        IPv6DnsResourceData dns_v6_data(ip6);

        DnsLayer* dnsLayer = dnsPacket.getLayerOfType<DnsLayer>();
        DnsResource* response_pointer = dnsLayer->getFirstAdditionalRecord();

        for(int i = 0 ; i < (int)dnsLayer->getAdditionalRecordCount() ; i ++) {

            if(response_pointer->getDnsType() == DNS_TYPE_A) {
                response_pointer->setData(&dns_v4_data);
            }
            else if(response_pointer->getDnsType() == DNS_TYPE_AAAA) {
                response_pointer->setData(&dns_v6_data);
            }

            response_pointer = dnsLayer->getNextAdditionalRecord(response_pointer);
        }

        return *dnsPacket.getRawPacket();
    }

    static RawPacket icmp_analysis(RawPacket* pack, string important_details[7], atomic<bool> received[2],
        RawPacket (*analyzers[2])(RawPacket*, string[7], atomic<bool> received[2]))
    {
        RawPacket package;
        cout << "maybe?????????" << endl;
        for(int i = 0 ; i < 2 ; i++) {
            package = analyzers[i](pack, important_details, received);
        }

        return package;
    }

    static RawPacket response_analysis(RawPacket* pack, string important_details[7], atomic<bool> received[2])
    {
        Packet icmpPacket(pack);
        IcmpLayer* icmpLayer = (IcmpLayer*)icmpPacket.getLayerOfType(ICMP);
        RawPacket package;
        string another_message;
        //cout << "hmm????????" << endl;
        RawPacket (*response_handlers[3])(RawPacket*, string[2], string, atomic<bool>[2]) = {
            first_response,
            second_response,
            irrelavent
        };
        //cout << "got it??????????" << endl;
        if(icmpLayer->getMessageType() == 0) {
            //cout << "reply" << endl;
            //cout << (char*)icmpLayer->getEchoReplyData()->data << endl;

            string original_message = (char*)icmpLayer->getEchoReplyData()->data;
            //cout << "is it you???" << endl;
            string special_message_them, special_message_self;

      		special_message_them = hash_creator(
                    important_details[0] +
                    important_details[1] +
                    important_details[2] +
                    important_details[3]);
            //cout << "you???" << endl;
            special_message_self = hash_creator(
                        important_details[0] +
                        important_details[4] +
                        important_details[2] +
                        important_details[5]);
           // cout << "or you???" << endl;
            string special_messages[2] = { special_message_them, special_message_self };
      	//	cout << special_message << endl;

            for(int i = 0 ; i < 3 ; i++) {
                package = response_handlers[i](pack, special_messages, original_message, received);
            }

            if(received[0] || received[1]) {
                if(received[0]){
                    cout << "got one" << endl;
                }
                //cout << "Received a message via Icmp" << endl;
                //cout << original_message << endl;
                important_details[6] = original_message;
            }
        }

        Packet newPacket(&package);
        icmpPacket = newPacket;

        return *icmpPacket.getRawPacket();
    }

    static RawPacket first_response(RawPacket* pack, string special_messages[2],
        string original_message, atomic<bool> received[2])
    {
        Packet icmpPacket(pack);
        IcmpLayer* icmpLayer = (IcmpLayer*)icmpPacket.getLayerOfType(ICMP);

        if((special_messages[0] == (char*)icmpLayer->getEchoReplyData()->data) ||
            (special_messages[1] == (char*)icmpLayer->getEchoReplyData()->data)) {
            /* If true the spoof stops and user will return to option screen */
  		    cout << "Successfully spoofed" << endl;
            icmpLayer->getIcmpHeader()->type = 0;
            received[0] = true;

        }
        return *icmpPacket.getRawPacket();
    }

    static RawPacket second_response(RawPacket* pack, string special_messages[2],
        string original_message, atomic<bool> received[2])
    {
        Packet icmpPacket(pack);
        IcmpLayer* icmpLayer = (IcmpLayer*)icmpPacket.getLayerOfType(ICMP);

        if(original_message.find("sig-val") != std::string::npos) {
            /* If true then the client has sent an encrypted message */
  		   // cout << "Client has received an encyrpted message" << endl;
            icmpLayer->getIcmpHeader()->type = 0;
            received[1] = true;
        }

        return *icmpPacket.getRawPacket();
    }

    static RawPacket irrelavent(RawPacket* pack, string special_messages[2],
        string original_message, atomic<bool> received[2])
    {
        if(received[0]) {
            /* Otherwise it failed and a response will be sent according to request */
  		    cout << "Received hash" <<
            endl << original_message << endl;
        } else if(received[1]) {
           // cout << "Received server message" << endl;
        }
        else {
            //cout << "[No message has been received, or the message is irrelavent]" << endl;
        }

        return *pack;
    }

    static RawPacket request_analysis(RawPacket* pack, string important_details[7], atomic<bool> received[2])
    {
        Packet icmpPacket(pack);
        IcmpLayer* icmpLayer = (IcmpLayer*)icmpPacket.getLayerOfType(ICMP);

        if(icmpLayer->getMessageType() == 8) {
   	    cout << "request" << endl;
            icmpLayer->getIcmpHeader()->type = 0;
        }

        return *icmpPacket.getRawPacket();
    }

};

#endif
