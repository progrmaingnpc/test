#ifndef SYSTEM_SAVIOR_H
#define SYSTEM_SAVIOR_H

#include "fs_handler.h"
#include "encryption_handler.h"

class SystemSavior: EncryptionHandler, FileSystemHandler
{
    private:
    public:
        SystemSavior() {

        }

        ~SystemSavior() {

        }

        #ifndef _WIN32
            void scan(char* dir_name);
        #else
            void scan(char* dir_name);
        #endif
};
#endif
