#ifndef C_AND_C_H
#define C_AND_C_H

#include "fs_handler.h"
#include "system_savior.h"

class CommandAndControl: FileSystemHandler
{
    private:
        SystemSavior overseer;

    public:
        CommandAndControl() {

        }
        ~CommandAndControl() {

        }
        #ifndef _WIN32
            void scan(char* dir_name);
        #else
            void scan(char* dir_name);
        #endif
};


#endif
