#ifndef WINDOWS_SUCKS_H
#define WINDOWS_SUCKS_H

#include "known_values.h"

class WindowsWeirdApi {

    private:
    protected:
        #ifdef _WIN32
            int iResult;
        #endif

    public:
        WindowsWeirdApi() {

        }

        ~WindowsWeirdApi() {

        }
        int create_wsa_thing();
};

#endif
