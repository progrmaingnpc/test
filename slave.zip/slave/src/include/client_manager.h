#ifndef CLIENT_MANAGER_H
#define CLIENT_MANAGER_H

#include "windows_sucks.h"
#include "tls_client.h"
#include "udp_client.h"

#define PORT 9930

class ClientManager {
    private:
        TlsClient tls_client;
        UdpClient udp_client;
        int disonnected;

    public:
        ClientManager() {

        }
        ~ClientManager() {

        }

        void create_sessions(string server_ip_address);
        void activate_socket(int socket_index);

        void main_manager_loop();
        void close_sessions();
};

#endif
