#ifndef ONE_TCP_SERVER_H
#define ONE_TCP_SERVER_H

#include "tcp_server_sockets.h"

class TcpServer : public TcpServerBasics {
    private:
        char message_buffer[1024];
        timeval timeout;
        size_t size;
    protected:
        vector<int> existing_tls_fd; //<-- If i create it here the udp class (unrelated to this class) wont crash
        int client_index = 0;
        #ifdef _WIN32
            SOCKET server_socket;
            SOCKET client_socket;
            SOCKADDR_IN server_address;
            int length_of_address;
        #else
            int server_socket;
            int client_socket;
            sockaddr_in server_address;
            socklen_t length_of_address;
        #endif
        int number_of_clients;
        fd_set active_fd_set;
        fd_set read_fd_set;
        fd_set write_fd_set;


    public:
        TcpServer() {
            this->number_of_clients = 0;
        }

        ~TcpServer() {

        }

        void create_socket_object();
        void bind_socket();

        void set_timout();
        inline void listen_to_connections() { listen(this->server_socket, 1); }

        void select_fd();
        void handle_client_connections();

        void accept_connection();
        #ifndef _WIN32
            int send_message(int filedes);
            int receive_message(int filedes);

            inline void close_client_socket (int filedes) {
                this->number_of_clients--;
                close(filedes);
            }
            inline void close_server_socket () { close(this->server_socket); }
        #else
            int send_message(SOCKET filedes);
            int receive_message(SOCKET filedes);

            inline void close_client_socket (SOCKET filedes) {
                this->number_of_clients--;
                closesocket(filedes);
            }
            inline void close_server_socket () { closesocket(this->server_socket); }

        #endif


        void create_session(int port);
};

#endif
