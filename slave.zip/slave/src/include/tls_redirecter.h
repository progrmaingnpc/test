#ifndef TLS_REDIRECTER_H
#define TLS_REDIRECTER_H

#include "one_tcp_server.h"

class TlsRedirecter : public TcpServer {
    protected:
        SSL_CTX* ctx;

    public:
        TlsRedirecter() {

        }
        ~TlsRedirecter() {

        }

        SSL_CTX* create_context();
        void configure_context();

        void create_ssl_context();
        void handle_client_connections();

        inline void close_server_socket () {
            #ifndef _WIN32
                close(this->server_socket);
            #else
                closesocket(this->server_socket);
            #endif
            SSL_CTX_free(this->ctx);
        };

};

#endif
