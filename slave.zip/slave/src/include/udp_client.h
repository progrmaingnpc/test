#ifndef UDP_CLIENT_H
#define UDP_CLIENT_H

#include "udp_basics.h"

// This is our server's IP address. In case you're wondering, this one is an RFC 5737 address.
//#define SRV_IP "203.0.113.61"
#define SRV_IP "192.168.122.48"

class UdpClient : public UdpBasics {
    private:
        char message_buffer[BUFLEN];
        timeval timeout;
        size_t size;
    protected:
        #ifdef _WIN32
            SOCKET client_socket;
            int length_of_address;
            SOCKADDR_IN server_address;
        #else
            int client_socket;
            socklen_t length_of_address;
            sockaddr_in server_address;
        #endif


    public:
        UdpClient() {

        }

        ~UdpClient() {

        }

        void create_socket_object();
        void set_timout();

        void keep_session();
        int send_message();

        int receive_message();

        void close_socket();
        void create_session(string server_ip_address);
};

#endif
