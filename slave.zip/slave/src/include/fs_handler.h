#ifndef FS_HANDLER_H
#define FS_HANDLER_H

#ifndef _WIN32
    #include <unistd.h>
    #include <sys/types.h> /* standard POSIX headers */
    #include <sys/stat.h>
    #include <dirent.h>
    #include <fcntl.h>
    #include <future>
#else
    //#include <windows.h>
    //#include <filesystem>

   // using std::filesystem::directory_entry;
   // using std::filesystem::directory_iterator;
   // using std::filesystem::directory_options;
   // using std::filesystem::recursive_directory_iterator;
#endif

#include <string>
#include <iostream>

using std::string;
using std::cout;
using std::endl;
using std::cerr;

#define TRUE 1
#define FALSE 0

class FileSystemHandler
{
    private:
        string base_path;
        #ifndef _WIN32
            string first_after_root[19] = {
                "bin", "boot", "dev",
                "etc", "home", "lib",
                "lib64", "mnt",
                "opt", "proc",
                "run",  "srv",
                "sys", "tmp",
                "root", "sbin",
                "usr", "var", "*"};
        #else
            string first_after_root[7] = {
                "Users", "Program Files (x86)",
                "Program Files", "ProgramData",
                "Windows", "PerfLogs", "*"
            };

            string registry_base_path = "Computer";
            string base_keys[8] = {
                "HKEY_CLASSES_ROOT", "HKEY_CURRENT_USER",
                "HKEY_LOCAL_MACHINE", "HKEY_USERS",
                "HKEY_CURRENT_CONFIG", "*"
            };
        #endif
    protected:
        #ifndef _WIN32
            struct stat sbuf; /* for lstat call to see if file is sym link */
        #endif
        int count_files;

    public:
        FileSystemHandler() {

        }
        ~FileSystemHandler() {

        }


        #ifndef _WIN32
            void create_path();
            string get_cwd();

            virtual void scan(char *dir_name) = 0;
            bool search_for_file(char* dir_name, string file_name);

            int verify_accessability(string file_name);
            void close_directory(DIR *dirp);
        #else
            virtual void scan(char *dir_name) = 0;
        #endif
};

#endif
