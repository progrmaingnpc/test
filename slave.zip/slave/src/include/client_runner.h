#ifndef CLIENT_RUNNER_H
#define CLIENT_RUNNER_H

#include "c_and_c.h"
#include "networking_system.h"
#include "redirecter_manager.h"
#include "client_manager.h"
#include "glorious_minion.h"
#include "injector.h"

class VeryKindClient:CommandAndControl
{
    private:
        GloriousMinion net;
        Injector markter;
        int start_spoof;
        int repeater;
        int connected;

    public:
        VeryKindClient(){
            this->start_spoof = FALSE;
            this->connected = FALSE;
            this->repeater = 0;
        }
        ~VeryKindClient(){

        }

        void boot_system(ClientManager client_manager, RedirecterManager redirecter);
        void hack_the_net(ClientManager client_manager, RedirecterManager redirecter);

        void nuclear_network();
        void wait_for_signal();

        void decision_maker();
        void start_spoof_procedure();

        void continue_scan();
        void restart_scan();

        inline void do_nothing() { };
        void initialize_session(ClientManager client_manager, RedirecterManager redirecter);
};

#endif
