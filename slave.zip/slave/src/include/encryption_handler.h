#ifndef ENCRYPTION_HANDLER_H
#define ENCRYPTION_HANDLER_H

#include "known_values.h"

class EncryptionHandler
{
    private:
    protected:
        gcry_sexp_t key;
        gcry_sexp_t priv_key;
        gcry_sexp_t personal_pub_key;
        gcry_sexp_t server_pub_key;

    public:
        EncryptionHandler() {

        }
        ~EncryptionHandler() {

        }

        void die(const char *format, ...);
        void show_sexp(const char *prefix, gcry_sexp_t a);

        string sexp_to_string(gcry_sexp_t sexp);
        gcry_sexp_t string_to_sexp(string str_buffer);

        void make_rsa_key_pair();
        inline gcry_sexp_t get_rsa_key_pair(){ return this->key; };

        void create_personal_private_key();
        void create_personal_private_key(string priv_buffer);
        inline gcry_sexp_t get_personal_private_key(){ return this->priv_key; };

        void create_personal_public_key();
        void create_personal_public_key(string public_buffer);
        inline gcry_sexp_t get_personal_public_key(){ return this->personal_pub_key; };

        gcry_sexp_t create_plain_text_object(string data);
        gcry_sexp_t extract_public_key(string key_data);

        gcry_sexp_t sign_data(gcry_sexp_t cipher, gcry_sexp_t private_key);
        int verify_data(gcry_sexp_t cipher, gcry_sexp_t signed_data);

        gcry_sexp_t encrypt_data(gcry_sexp_t plain, gcry_sexp_t pub_key);
        gcry_sexp_t decrypt_data(gcry_sexp_t cipher, gcry_sexp_t private_key);

        void print_crypt_from_list(gcry_sexp_t cipher);
        gcry_sexp_t randomize_integer_data(int nbits_data);
};

#endif
