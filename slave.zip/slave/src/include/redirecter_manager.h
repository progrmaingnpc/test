#ifndef SERVER_MANAGER_H
#define SERVER_MANAGER_H

#include "tls_redirecter.h"

#define HTTP_PORT 80
#define HTTPS_PORT 443

class RedirecterManager {
    private:
        TcpServer http_redirect_server;
        TlsRedirecter https_redirect_server;

    public:
        RedirecterManager() {

        }
        ~RedirecterManager() {

        }

        void create_sessions();
        void redirecters_loop();

        void activate_redirecters(int socket_index);
        void close_sessions();
};

#endif
