#ifndef UDP_BASICS_H
#define UDP_BASICS_H

#include "known_values.h"

#define BUFLEN 1024
#define PORT 9930

class UdpBasics {
    protected:
        #ifdef _WIN32
            int iResult;
        #endif
    public:
        virtual inline void create_socket_object() = 0;

        #ifdef _WIN32
            SOCKADDR_IN specify_server_address(string server_ip_address);
        #else
            sockaddr_in specify_server_address(string server_ip_address);
        #endif

        virtual void keep_session() = 0;
        virtual void close_socket() = 0;
};

#endif
