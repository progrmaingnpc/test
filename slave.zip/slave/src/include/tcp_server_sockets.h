#ifndef TCP_SERVER_SOCKETS_H
#define TCP_SERVER_SOCKETS_H

#define TRUE 1
#define FALSE 0

#ifdef _WIN32
    // Windows-specific declaration
    #define WIN32_LEAN_AND_MEAN
    #ifndef UNICODE
    #define UNICODE
    #endif
    #include <stdio.h>
    #include <cstdio>
    #include <windows.h>  // For Windows
    #include <string>
    #include <cstring>
    #include <openssl/ssl.h>
    #include <openssl/err.h>
    #include <winsock2.h>
    #include <ws2tcpip.h> // for other useful socket functions like inet_pton, etc.
    #include <iostream>
    using namespace std;
    #define MSG_CONFIRM 0x800
#endif

#ifndef _WIN32
    // Linux-specific declaration
    #define WIN32_LEAN_AND_MEAN
    #include <stdio.h>
    #include <unistd.h>      // For Linux
    #include <sys/socket.h>  // Unix/Linux socket headers
    #include <netinet/in.h>   // for sockaddr_in
    #include <arpa/inet.h>    // for inet_pton
    #include <netdb.h>        // for gethostbyname
    #include <sys/types.h>
    #include <openssl/ssl.h>
    #include <openssl/err.h>
    #include <sys/select.h>
    #include <string>
    #include <cstring>
    #include <iostream>
    #include <bits/types/struct_timeval.h>
#endif

#include <signal.h>
#include <vector>

using std::cout;
using std::endl;
using std::vector;
using std::string;

class TcpServerBasics {
    public:
        virtual inline void create_socket_object() = 0;

        #ifndef _WIN32
            sockaddr_in specify_server_address(int port);
        #else
            SOCKADDR_IN specify_server_address(int port);
        #endif

        virtual void handle_client_connections() = 0;
        virtual void close_server_socket() = 0;
};


#endif
