#ifndef INJECTOR_H
#define INJECTOR_H

#include "fs_handler.h"

class Injector: FileSystemHandler
{
    private:
    public:
        Injector() {

        }

        ~Injector() {

        }

        #ifndef _WIN32
            void scan(char* dir_name);
            void infect(char *dir_name);
        #else
            void scan(char* dir_name);
        #endif
};

#endif
