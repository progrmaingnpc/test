#ifndef GLORIOUS_MINION_H
#define GLORIOUS_MINION_H

#include "networking_system.h"
#include "pem_file_analyzer.h"

class GloriousMinion: NetworkingSystem, PemHandler
{
    private:
        int started_time_measurement;
        clock_t timer;
        uint16_t src_port;
        string found_ip;
        string target_user_ip;
        string target_user_mac;
        RawPacket arpNetResponses;
        RawPacket arpTargetResponses;
        atomic<bool> past_condition_lock; // PRIVATE ATOMIC BOOL PROPERTY
        string UnHandledMessage;
    public:
        int scanned_prefixes;
        atomic<bool> input_condition_lock; // PUBLIC ATOMIC BOOL PROPERTY
        atomic<bool> spoof_inititiated;
        mutex the_other_lock; // Global input buffer lock
        string server_ip_address;
        atomic<bool> found_server;
        atomic<bool> connected;

        GloriousMinion() {
            this->past_condition_lock = false;
            this->input_condition_lock = false;

            this->started_time_measurement = 0;
            this->scanned_prefixes = 0;

            this->src_port = 53;
            this->spoof_inititiated = false;

            this->found_server = false;
            this->connected = false;

            this->target_user_ip = "0.0.0.0";
            this->target_user_mac = "00:00:00:00:00:00";
        }

        ~GloriousMinion() {

        }


        void listInterfaceNames();
        void tester();

        void sniffer();
        void sniffer_spoof();

        void handle_received_data();

        RawPacket create_arp_is_at(string new_route, string target_ip, string mac_address);
        RawPacket create_arp_who_is(string target_ip);

        int prepared_to_nuke();
        void get_key_network_details();

        void Map_The_Net();
        void move_to_next_user(string mac_address, int user_index);

        void Request_Mac_Address(string target_ip);
        void wait();

        void restart_timer();
        void Restart_Mapping(int user_index);
        void trigger_spoof();

        void create_network_arp_replies();
        void create_target_replies();

        RawPacket Identify();
        inline virtual atomic<bool> still_capturing() { return this->communicator->captureActive(); };

        void Change_user_route();
        void send_changes();

        void move_to_the_next_target();
        int store_index_for_tech_support(int converted_index);
        //
        inline void stop_capture() { this->communicator->stopCapture(); };
        inline void close_device() { this->communicator->close(); };

        void List_potential_users();
        int Choose_users();

        void print_targets(string target_ip);
        int enter_target_indexs(int list_type);

        void store_chosen_targets(int converted_index);
        int store_chosen_targets(int converted_index, int list_type);

        int store_for_spoof(int converted_index);
        void send_encrypted_message(RawPacket* pack);

        string encrypt_details();
        void Handle_situation(string message_data);

        void Authenticate_message(string message_data);
        void Verify_message_structure(string message_data);

        bool are_params_there(string message_data, string param_list[3]);
        bool are_params_in_order(string message_data, string param_list[3]);

        void dissect_message(string message_data);
        void verify_signature(string sig, string the_hash);

        void verify_signature_auth(gcry_sexp_t signed_data, string the_hash);
        static int pass_cb(char *buf, int size, int rwflag, void *u);

        string get_username();
};

#endif
