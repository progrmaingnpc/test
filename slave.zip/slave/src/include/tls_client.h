#ifndef TLS_CLIENT_H
#define TLS_CLIENT_H

#include "tcp_client_socket.h"

class TlsClient : public TcpClientBasics {
    private:
        #ifdef _WIN32
            SOCKET server_socket;
            SOCKET client_socket;
            SOCKADDR_IN server_address;
            int length_of_address;
        #else
            int server_socket;
            int client_socket;
            sockaddr_in server_address;
            socklen_t length_of_address;
        #endif
            char message_buffer[1024];
            const char* message = "Hello there";
            SSL_CTX* ctx;
            SSL* ssl;

    public:
        TlsClient () {
            this->client_socket = create_socket_object();

            #ifdef _WIN32
                if (this->client_socket== INVALID_SOCKET) {
                    wprintf(L"socket function failed with error: %ld\n", WSAGetLastError());
                    WSACleanup();
                }
            #endif
        }

        ~TlsClient() {

        }

        #ifndef _WIN32
            int create_socket_object();
        #else
            SOCKET create_socket_object();
        #endif

        void connect_to_server();
        SSL_CTX* create_context();

        void configure_ssl_context();
        inline void send_message() { SSL_write(this->ssl, this->message, strlen(this->message)); }

        void close_connection();
        void create_session(string server_ip_address);
};

#endif
