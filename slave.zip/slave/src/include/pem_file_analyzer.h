#ifndef PEM_FILE_ANALYZER_H
#define PEM_FILE_ANALYZER_H

#ifndef _WIN32
    #include "known_values.h"
#else
    #define WIN32_LEAN_AND_MEAN
    #include <stdio.h>
    #include <windows.h>  // For Windows
    #include <string>
    #include <cstring>
    #include <stdint.h>
    #include <stdlib.h>
    #include <winsock2.h>
    #include <ws2tcpip.h> // for other useful socket functions like inet_pton, etc.
    #include <ws2ipdef.h>
    #include <iphlpapi.h>
    #include <iostream>
    #include <iomanip>
    #include <inaddr.h>
    #include <openssl/ssl.h>
    #include <openssl/err.h>
    #include <openssl/rsa.h>
    #include <openssl/crypto.h>
    #include <openssl/pem.h>
    #include <openssl/bio.h>
    #include <openssl/bioerr.h>
    #include <openssl/conf.h>
    #include <openssl/x509v3.h>
    #include <openssl/bn.h>
    #include <openssl/asn1.h>
    #include <openssl/x509.h>
    #include <openssl/x509_vfy.h>
    #include <openssl/ossl_typ.h>
    #include <openssl/evp.h>
    #include <openssl/decoder.h>
    #include <openssl/encoder.h>
    #include <openssl/bn.h>
    #include <filesystem>
    using namespace std;
#endif

class PemHandler
{
    private:
    protected:
        FILE *fp1;
        FILE *fp2;
        X509* cert;
        BIO *priv_bio;
        BIO *pub_bio;
        EVP_PKEY* personal_private_key;
        EVP_PKEY* public_key;

    public:
        PemHandler() {

        }
        ~PemHandler() {

        }

        void open_essential_tools();
        int open_certificate_pem(string file_name);
        int open_private_key_pem(string file_name);

        int open_openssl_buffers();
        int extract_certificate_from_file();

        string remove_unnecessary_details(string pem_buffer);
        string extract_public_tools();

        string extract_public_key_from_pem(string pem_buffer);
        string extract_public_modulus_from_pem(string pem_buffer);
        string extract_public_exp_from_public_pem(string pem_buffer);

        string extract_private_tools();
        string extract_private_key_from_pem(string pem_buffer);
        string extract_n_param_from_pem(string pem_buffer);

        string extract_public_exp_from_private_pem(string pem_buffer);
        string extract_d_param_from_pem(string pem_buffer);

        string extract_p_prime_from_pem(string pem_buffer);
        string extract_q_prime_from_pem(string pem_buffer);

        string create_inverse_coeffecient(string pem_buffer);
        void close_file(FILE *fp) { fclose(fp); };
};

#endif
