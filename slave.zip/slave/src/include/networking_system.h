#ifndef NETWORK_SYSTEM_H
#define NETWORK_SYSTEM_H

#include "encryption_handler.h"

class NetworkingSystem: public EncryptionHandler
{
    private:
        mutex the_capture_lock;

    protected:
        int pack_size;
        int timeoutSec;
        string device_name;
        string src_mac_addr;
        string dst_mac_addr;
        string src_ip;
        string dst_ip;
        string servers_ip;
        string gateway_ip;
        string network_mac;
        string broadcast_mac;
        double capture_time;
        networkdata network_data;
        PcapLiveDevice* communicator;
        mutex the_lock;

    public:
        //static
        NetworkingSystem() {
            this->device_name = "enp2s0";
            this->src_mac_addr = "7c:8a:e1:c2:72:dc";

            this->dst_mac_addr = "7c:8a:e1:c2:72:dc";
            this->servers_ip = "127.0.0.1"; // <-- My ip

            this->src_ip = "127.0.0.1";
            this->dst_ip = "127.0.0.1";

            this->pack_size = 200;
            this->capture_time = 0;

            this->timeoutSec = 1;
            this->broadcast_mac = "ff:ff:ff:ff:ff:ff";
        }

        ~NetworkingSystem() {

        }

        string toHex(const Type& number);
        string increment_address(const char* address_string);

        virtual void listInterfaceNames() = 0;
        int choose_interface_name(char* interface_name);

        void Print_interface_details();
        static void OnRedirectedPacketArrives(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);

        static bool is_packet_irrelavent(RawPacket* packet);
        static void handle_non_dns_packets(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);

        static int wanted_user(RawPacket* packet, void* cookie);
        static int find_related_mac(RawPacket* packet, void* cookie);

        static void dns_spoof(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);
        static void redirect_dns_packet(RawPacket* packet, void* cookie, uint16_t dns_message_type);

        static int wanted_domain_in_response(string domain_name, void* cookie);
        static void handle_wanted_dns_response(RawPacket* packet, void* cookie, int index);

        static void HandleArpPackets(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);
        static void shut_the_fuck_up(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);

        static void HandleIcmpPackets(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);

        static string extract_the_ip(RawPacket* packet);
        static void redirect_icmp_to_client(RawPacket* packet, PcapLiveDevice* capture_device, void* cookie);
        static void store_user(void* cookie, string user[2]);
        void get_dns_servers();
        int open_device();

        void Capture_packet();
        void Capture_packet(string target_ip, string target_mac);

        inline virtual atomic<bool> still_capturing() = 0;
        //Calculate all necassary fields of the packet
        inline void master_calculator(Packet* newPacket) { newPacket->computeCalculateFields();};
        inline virtual void close_device() = 0;
};

#endif
