#include "include/one_tcp_server.h"

void TcpServer::create_socket_object()
{
    this->server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (this->server_socket < 0) {
        perror("Unable to create sockeet");
        exit(EXIT_FAILURE);
    }
}

void TcpServer::bind_socket()
{
    if (bind(this->server_socket, (struct sockaddr*)&this->server_address, this->length_of_address) < 0) {
        perror("Unable to bind");
        exit(EXIT_FAILURE);
    }
}

void TcpServer::set_timout()
{
    FD_ZERO (&this->active_fd_set);
    FD_SET (this->server_socket, &this->active_fd_set);

    this->timeout.tv_sec = 0;
    this->timeout.tv_usec = 5;

    #ifdef _WIN32
        int a = 1;
        if (setsockopt(this->server_socket, SOL_SOCKET, SO_RCVBUF, (char *)&a, sizeof(a)) < 0) {
            cout << "[Failed to set socket timeout]" << endl;
            WSACleanup();
            exit(EXIT_FAILURE);
        }
        if (setsockopt(this->server_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&a, sizeof(a)) < 0) {
            cout << "[Failed to make socket reusable]" << endl;
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        if (setsockopt(this->server_socket, SOL_SOCKET, SO_RCVTIMEO, &this->timeout, sizeof(this->timeout)) < 0) {
            cout << "[Failed to set socket timeout]" << endl;
            perror("timeout");
            exit(EXIT_FAILURE);
        }
        if (setsockopt(this->server_socket, SOL_SOCKET, SO_REUSEADDR, &this->timeout, sizeof(this->timeout)) < 0) {
            cout << "[Failed to make socket reusable]" << endl;
            exit(EXIT_FAILURE);
        }
    #endif
}

void TcpServer::select_fd()
{
    this->read_fd_set = this->active_fd_set;
    if (select(FD_SETSIZE+1, &this->read_fd_set, NULL, NULL, &this->timeout) < 0) {
        perror ("select");
        return;
    }
}

void TcpServer::handle_client_connections()
{
    for (this->client_index = 0; this->client_index < FD_SETSIZE; ++this->client_index) {
        if (FD_ISSET (this->client_index, &this->read_fd_set)) {
            if (this->client_index == this->server_socket) {
                /* Connection request on original socket. */
                accept_connection();
            }
            else {
                /* Data arriving on an already-connected socket. */
                if (receive_message(this->client_index) < 0) {
                    close_client_socket(this->client_index);
                    perror ("closed after recieve");
                    FD_CLR (this->client_index, &this->active_fd_set);
                }
                else if(send_message(this->client_index) < 0) {
                    close_client_socket(this->client_index);
                    perror ("closed after response");
                    FD_CLR (this->client_index, &this->active_fd_set);
                }
            }
        }
    }
}

void TcpServer::accept_connection()
{
    this->client_socket = accept(this->server_socket, (struct sockaddr*)&this->server_address, &this->length_of_address);
    if (this->client_socket < 0) {
        perror ("accept");
        return;
    }
    cout << "SOck value " << this->client_socket << endl;
    fprintf (stderr,
                "Server: connect from host %s, port %hd.\n",
                inet_ntoa(this->server_address.sin_addr),
                ntohs (this->server_address.sin_port));
    FD_SET(this->client_socket, &this->active_fd_set);
}
#ifndef _WIN32
    int TcpServer::send_message(int filedes)
    {
        //char redirect_message[] = "HTTP/1.1 307 Internal Redirect\r\nLocation: https://www.youtube.com/watch?v=dQw4w9WgXcQ\r\nCross-Origin-Resource-Policy: Cross-Origin\r\nNon-Authoritative-Reason: HSTS\r\n\r\n";
        char redirect_message[] = "HTTP/1.1 307 Internal Redirect\r\nLocation: https://progrmaingnpc.github.io/test/\r\nCross-Origin-Resource-Policy: Cross-Origin\r\nNon-Authoritative-Reason: HSTS\r\n\r\n";

        ssize_t sent;
        sent = send(filedes, &redirect_message, sizeof(redirect_message), 0);
        if(sent < 0) {
            /* Send error. */
            perror ("send");
            return -1;
        }
        else {
            /* Data write. */
            cout << "[Data has been successfully sent to the client]" << endl;
            return 0;
        }
    }

    int TcpServer::receive_message(int filedes)
    {
        ssize_t nbytes;
        nbytes = recv(filedes, this->message_buffer, sizeof(this->message_buffer), 0);
        if (nbytes < 0){
            /* Read error. */
            perror ("recv");
            return -2;
        }
        else if (nbytes == 0){
            /* End-of-file. */
            perror ("recv");
            return -1;
        }
        else
        {
            /* Data read. */
            fprintf (stderr, "Server: got message: `%s'\n", this->message_buffer);
            return 0;
        }
    }

#else
    int TcpServer::send_message(SOCKET filedes)
    {
        //char redirect_message[] = "HTTP/1.1 307 Internal Redirect\r\nLocation: https://www.youtube.com/watch?v=dQw4w9WgXcQ\r\nCross-Origin-Resource-Policy: Cross-Origin\r\nNon-Authoritative-Reason: HSTS\r\n\r\n";
        const char redirect_message[] = "HTTP/1.1 307 Internal Redirect\r\nLocation: https://progrmaingnpc.github.io/test/\r\nCross-Origin-Resource-Policy: Cross-Origin\r\nNon-Authoritative-Reason: HSTS\r\n\r\n";
        int sent;
        sent = send(filedes, redirect_message, sizeof(redirect_message), 0);
        if(sent < 0) {
            /* Send error. */
            perror ("send");
            return -1;
        }
        else {
            /* Data write. */
            cout << "[Data has been successfully sent to the client]" << endl;
            return 0;
        }
    }

    int TcpServer::receive_message(SOCKET filedes)
    {
        int nbytes;
        nbytes = recv(filedes, this->message_buffer, sizeof(this->message_buffer), 0);
        if (nbytes < 0){
            /* Read error. */
            perror ("recv");
            return -2;
        }
        else if (nbytes == 0){
            /* End-of-file. */
            perror ("recv");
            return -1;
        }
        else
        {
            /* Data read. */
            fprintf (stderr, "Server: got message: `%s'\n", this->message_buffer);
            return 0;
        }
    }
#endif

void TcpServer::create_session(int port)
{
    this->server_address = specify_server_address(port);
    this->length_of_address = sizeof(this->server_address);

    create_socket_object();
    bind_socket();

    set_timout();
    listen_to_connections();
}
