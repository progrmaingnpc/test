#include "include/system_savior.h"

#ifndef _WIN32
    void SystemSavior::scan(char* dir_name)
    {
        /* Recursively search */
        DIR *dirp; /* pointer to an open directory stream */
        struct dirent *dp; /* pointer to a directory entr y */

        dirp = opendir(dir_name); /* open this directory */
        if (dirp == NULL) {
            return; /* dir could not be opened; forget it */
        }
        while (TRUE) {
            dp = readdir(dirp); /* read next directory entry */

            if (dp == NULL) { /* NULL means we are done */
                chdir (".."); /* go back to parent directory */
                break; /* exit loop */
            }

            if (((string)dp->d_name == ".") || (dp->d_name[1] == '.')) continue; /* skip the . and .. directories */
            lstat(dp->d_name, &sbuf); /* is entry a symbolic link? */
            if (S_ISLNK(sbuf.st_mode)) continue; /* skip symbolic links */

            if (chdir(dp->d_name) == 0) { /* if chdir succeeds, it must be a dir */
            //   cout << dp->d_name << endl;
                scan((char*)"."); /* yes, enter and search it */
            } else { /* no (file), infect it */
                this->count_files++;
                //if(((string)dp->d_name == ".bashrc") ||
                //    ((string)dp->d_name == ".zshrc")
                //    ){
                //    cout << "Found " << dp->d_name << " at " << get_cwd() << endl;
                //}
            }
        }
        close_directory(dirp);
    }
#else
    void SystemSavior::scan(char* dir_name)
    {

    }
#endif
